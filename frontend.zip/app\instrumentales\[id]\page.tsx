"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import OrderModal from "@/components/order/OrderModal";
import Toast from "@/components/ui/Toast";
import ReviewSection from "@/components/instrumental/ReviewSection";
import FollowButton from "@/components/producer/FollowButton";
import AddToPlaylistButton from "@/components/playlist/AddToPlaylistButton";
import CoverImage from "@/components/ui/CoverImage";
import { usePlayer } from "@/context/PlayerContext";
import { useAuthModal } from "@/context/AuthModalContext";
import { Heart, ShieldCheck, Music, Timer, Activity, Tag, Play, Pause, Download } from "lucide-react";
import { formatPrice } from "@/lib/format";

type InstrumentalDetail = {
  id: number;
  title: string;
  description: string | null;
  cover_path: string | null;
  bpm: number | null;
  musical_key: string | null;
  duration_seconds: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  status: string;
  producer?: { id: number; display_name: string; verified: boolean } | null;
  genre?: { label: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
  files?: { id: number; type: string }[];
};

type OrderPayment = {
  mobile_number: string;
  holder_name: string;
  reference: string;
  amount: number;
};

type PageProps = Readonly<{
  params: Promise<{ id: string }>;
}>;

export default function InstrumentalDetailPage({ params }: PageProps) {
  const { id } = use(params);

  const [instrumental, setInstrumental] = useState<InstrumentalDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [orderType, setOrderType] = useState<"non_exclusive" | "exclusive" | null>(null);
  const [payment, setPayment] = useState<OrderPayment | null>(null);
  const [orderLoading, setOrderLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; variant: "success" | "error" } | null>(null);

  const [isFavorited, setIsFavorited] = useState(false);
  const [favoriteLoading, setFavoriteLoading] = useState(false);

  // Contexte global
  const { currentTrack, isPlaying, playTrack, togglePlay } = usePlayer();
  const { openAuthModal } = useAuthModal();
  
  const isCurrent = currentTrack?.id === Number(id);
  const isCurrentlyPlaying = isCurrent && isPlaying;

  useEffect(() => {
    async function loadInstrumental() {
      try {
        const res = await api.get(`/instrumentals/${id}`);
        setInstrumental(res?.data);
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : "Erreur de chargement");
      } finally {
        setLoading(false);
      }
    }
    void loadInstrumental();
  }, [id]);

  useEffect(() => {
    async function checkFavorite() {
      if (!auth.isAuthenticated() || !instrumental) return;
      try {
        const res = await api.get(`/favorites/${instrumental.id}/check`);
        setIsFavorited(res?.is_favorited ?? false);
      } catch {}
    }
    void checkFavorite();
  }, [instrumental]);

  const formatDuration = (seconds: number) => {
    if (!seconds || isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const handleBuy = async (type: "non_exclusive" | "exclusive") => {
    if (!auth.isAuthenticated()) {
      openAuthModal({ 
        id: instrumental!.id, 
        title: instrumental!.title, 
        coverPath: instrumental!.cover_path, 
        price: type === "exclusive" ? instrumental!.exclusive_price : instrumental!.non_exclusive_price 
      });
      return;
    }
    setOrderLoading(true);
    setOrderType(type);
    try {
      const res = await api.post("/orders", { instrumental_id: instrumental?.id, type });
      setPayment(res.payment);
    } catch (e: unknown) {
      setToast({ message: e instanceof Error ? e.message : "Erreur", variant: "error" });
      setOrderType(null);
    } finally {
      setOrderLoading(false);
    }
  };

  const closeOrderModal = () => {
    setOrderType(null);
    setPayment(null);
  };

  const handleToggleFavorite = async () => {
    if (!auth.isAuthenticated()) {
      openAuthModal({ id: instrumental!.id, title: instrumental!.title, coverPath: instrumental!.cover_path, price: instrumental!.non_exclusive_price });
      return;
    }
    setFavoriteLoading(true);
    try {
      if (isFavorited) {
        await api.delete(`/favorites/${instrumental!.id}`);
        setIsFavorited(false);
      } else {
        await api.post(`/favorites/${instrumental!.id}`);
        setIsFavorited(true);
      }
    } catch (e: unknown) {
      setToast({ message: e instanceof Error ? e.message : "Erreur", variant: "error" });
    } finally {
      setFavoriteLoading(false);
    }
  };

  const handlePlayToggle = () => {
    if (!instrumental) return;
    if (isCurrent) {
      togglePlay();
    } else {
      const previewUrl = `${process.env.NEXT_PUBLIC_API_URL}/instrumentals/${instrumental.id}/preview`;
      const track = {
        id: instrumental.id,
        title: instrumental.title,
        producerName: instrumental.producer?.display_name,
        coverPath: instrumental.cover_path,
        previewUrl,
      };
      playTrack(track, [track]);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p className="text-gray-500">Chargement...</p>
      </div>
    );
  }

  if (error || !instrumental) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <p className="text-red-500 mb-4">{error || "Instrumentale introuvable."}</p>
        <Link href="/catalogue">
          <Button variant="secondary">Retour au catalogue</Button>
        </Link>
      </div>
    );
  }

  const hasPreview = instrumental.files?.some((f) => f.type === "preview");

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {toast && <Toast message={toast.message} variant={toast.variant} onClose={() => setToast(null)} />}

      <Link
        href="/catalogue"
        className="inline-flex items-center text-sm text-gray-500 hover:text-accent mb-8 transition-colors"
      >
        ← Retour au catalogue
      </Link>

      <div className="flex flex-col md:flex-row gap-8 md:gap-12 items-start mb-12">
        
        {/* COLONNE GAUCHE : POCHETTE + BOUTONS D'ACTION */}
        <div className="w-full md:w-[380px] shrink-0">
          <div className="relative w-full aspect-square rounded-2xl overflow-hidden bg-background-secondary border border-border shadow-lg group">
            <CoverImage
              src={instrumental.cover_path}
              alt={instrumental.title}
              id={instrumental.id}
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            />

            <div className="absolute top-3 left-3 bg-dark/70 backdrop-blur-md px-2.5 py-1 rounded-md text-[10px] font-bold text-white tracking-wider">
              INSTRUNAKA · ÉDITION 01
            </div>

            <button
              onClick={handleToggleFavorite}
              disabled={favoriteLoading}
              className={`absolute top-3 right-3 w-8 h-8 rounded-full backdrop-blur-sm flex items-center justify-center transition-all ${
                isFavorited
                  ? "bg-red-500 text-white"
                  : "bg-white/90 text-content hover:text-red-500 hover:bg-white"
              }`}
              aria-label="Ajouter aux favoris"
            >
              <Heart className="w-4 h-4" fill={isFavorited ? "currentColor" : "none"} />
            </button>

            {hasPreview && (
              <div 
                className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center cursor-pointer"
                onClick={handlePlayToggle}
              >
                <div className="w-16 h-16 rounded-full bg-white/95 backdrop-blur-sm flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
                  {isCurrentlyPlaying ? (
                    <Pause className="w-7 h-7 text-accent" fill="currentColor" />
                  ) : (
                    <Play className="w-7 h-7 text-accent ml-1" fill="currentColor" />
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3 mt-6">
            <button
              onClick={handleToggleFavorite}
              disabled={favoriteLoading}
              className={`w-12 h-12 rounded-full flex items-center justify-center border transition-colors ${
                isFavorited
                  ? "bg-accent border-accent text-white"
                  : "bg-white border-border text-content hover:border-accent/50 hover:text-accent"
              }`}
              aria-label="Favori"
            >
              <Heart className="w-5 h-5" fill={isFavorited ? "currentColor" : "none"} />
            </button>
            
            <AddToPlaylistButton instrumentalId={instrumental.id} size="md" />
          </div>
        </div>

        {/* COLONNE DROITE : TITRE, ARTISTE, CARACTÉRISTIQUES, LECTEUR WAVEFORM */}
        <div className="flex-1 min-w-0">
          <p className="text-xs font-semibold text-accent uppercase tracking-widest mb-2">
            {instrumental.genre?.label || "Instrumentale"}
          </p>
          
          <h1 className="text-4xl md:text-5xl font-bold text-content mb-3 leading-tight tracking-tight">
            {instrumental.title}
          </h1>
          
          <div className="flex items-center gap-2 mb-6">
            <span className="text-content-secondary text-sm">par</span>
            <Link
              href={`/producteurs/${instrumental.producer?.id}`}
              className="text-accent hover:text-accent-hover font-semibold text-sm transition-colors"
            >
              {instrumental.producer?.display_name}
            </Link>
            {instrumental.producer?.verified && (
              <ShieldCheck className="w-4 h-4 text-accent" />
            )}
            <div className="ml-4">
              <FollowButton producerId={instrumental.producer?.id ?? 0} size="sm" />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-sm text-content-secondary mb-6">
            {instrumental.bpm && <span className="flex items-center gap-1.5"><Activity className="w-4 h-4" /> {instrumental.bpm} BPM</span>}
            {instrumental.musical_key && <span className="flex items-center gap-1.5"><Music className="w-4 h-4" /> {instrumental.musical_key}</span>}
            {instrumental.mood && <span className="flex items-center gap-1.5"><Tag className="w-4 h-4" /> {instrumental.mood.label}</span>}
            {instrumental.rhythm && <span className="flex items-center gap-1.5"><Activity className="w-4 h-4" /> {instrumental.rhythm.label}</span>}
            {instrumental.duration_seconds && <span className="flex items-center gap-1.5"><Timer className="w-4 h-4" /> {formatDuration(instrumental.duration_seconds)}</span>}
          </div>

          {instrumental.description && (
            <p className="text-sm text-content-secondary leading-relaxed mb-8">
              {instrumental.description}
            </p>
          )}

          {/* LECTEUR WAVEFORM INTÉGRÉ (Connecté au contexte global) */}
          {hasPreview && (
            <div className="bg-background-secondary rounded-2xl p-6 border border-border">
              <div className="flex items-center gap-4 mb-3">
                <button 
                  onClick={handlePlayToggle}
                  className="w-12 h-12 rounded-full bg-accent hover:bg-accent-hover flex items-center justify-center text-white shadow-md transition-colors shrink-0"
                >
                  {isCurrentlyPlaying ? <Pause className="w-5 h-5" fill="currentColor" /> : <Play className="w-5 h-5 ml-0.5" fill="currentColor" />}
                </button>
                <div className="text-sm font-medium text-content-secondary font-mono w-24">
                  {isCurrent ? "En lecture..." : "Écouter l'extrait"}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* SECTION ACHAT */}
      <div className="bg-white border border-border rounded-2xl p-6 md:p-8 mb-12 shadow-sm">
        <h2 className="text-xl font-bold text-content mb-6">Acheter cette instrumentale</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-border">
              <div><p className="text-content font-semibold">Licence Standard</p><p className="text-content-secondary text-xs mt-1">MP3 + WAV · Usage non exclusif</p></div>
              <span className="text-xl font-bold text-content">{formatPrice(instrumental.non_exclusive_price)}</span>
            </div>
            <Button variant="secondary" className="w-full rounded-full" loading={orderLoading && orderType === "non_exclusive"} onClick={() => handleBuy("non_exclusive")}>
              <Download className="w-4 h-4 mr-2" />
              Télécharger
            </Button>
          </div>
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-4 border-b border-border">
              <div><p className="text-content font-semibold">Licence Exclusive</p><p className="text-content-secondary text-xs mt-1">MP3 + WAV · Propriété unique</p></div>
              <span className="text-xl font-bold text-accent">{formatPrice(instrumental.exclusive_price)}</span>
            </div>
            <Button variant="primary" className="w-full rounded-full bg-accent hover:bg-accent-hover text-white shadow-lg shadow-accent/20" loading={orderLoading && orderType === "exclusive"} onClick={() => handleBuy("exclusive")}>
              Acheter
            </Button>
          </div>
        </div>
        <p className="text-xs text-content-secondary mt-6 flex items-center gap-1"><ShieldCheck className="w-3 h-3" /> Paiement par Mobile Banking, validé manuellement.</p>
      </div>

      <div className="border-t border-border pt-10"><ReviewSection instrumentalId={instrumental.id} /></div>
      <OrderModal isOpen={!!payment} onClose={closeOrderModal} payment={payment} orderType={orderType ?? "non_exclusive"} instrumentalTitle={instrumental.title} />
    </div>
  );
}