"use client";

import { useState } from "react";
import { api } from "@/lib/api";
import Card from "@/components/ui/Card";
import Button from "@/components/ui/Button";
import Toast from "@/components/ui/Toast";
import { PLATFORM } from "@/lib/config";

export default function ContactPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [subject, setSubject] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; variant: "success" | "error" } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      const res = await api.post("/contact", { name, email, subject, message });
      setToast({ message: res.message, variant: "success" });
      setName("");
      setEmail("");
      setSubject("");
      setMessage("");
    } catch (e: unknown) {
      setToast({
        message: e instanceof Error ? e.message : "Erreur d'envoi",
        variant: "error",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl">
      {toast && <Toast message={toast.message} variant={toast.variant} onClose={() => setToast(null)} />}

      <div className="text-center mb-8">
        <h1 className="text-4xl font-bold mb-3">📬 Contactez-nous</h1>
        <p className="text-content-secondary">
          Une question, une suggestion, un problème ? Notre équipe vous répondra dans les plus brefs délais.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card padding="md" className="text-center">
          <span className="text-3xl block mb-2">📧</span>
          <p className="text-xs text-content-secondary mb-1">Email</p>
          <a href={`mailto:${PLATFORM.contact.email}`} className="text-accent hover:underline text-sm font-medium break-all">
            {PLATFORM.contact.email}
          </a>
        </Card>
        <Card padding="md" className="text-center">
          <span className="text-3xl block mb-2">📞</span>
          <p className="text-xs text-content-secondary mb-1">Téléphone</p>
          <p className="text-sm font-medium">{PLATFORM.contact.phone}</p>
        </Card>
        <Card padding="md" className="text-center">
          <span className="text-3xl block mb-2">📍</span>
          <p className="text-xs text-content-secondary mb-1">Adresse</p>
          <p className="text-sm font-medium">{PLATFORM.contact.address}</p>
        </Card>
      </div>

      <Card padding="lg">
        <h2 className="text-xl font-semibold mb-4">Envoyez-nous un message</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1">Nom *</label>
              <input
                required
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-border bg-background focus:border-accent outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Email *</label>
              <input
                required
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-border bg-background focus:border-accent outline-none"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Sujet</label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-border bg-background focus:border-accent outline-none"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Message *</label>
            <textarea
              required
              rows={6}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-border bg-background focus:border-accent outline-none"
            />
          </div>
          <Button type="submit" loading={loading} className="w-full">
            Envoyer le message
          </Button>
        </form>
      </Card>
    </div>
  );
}