"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Toast from "@/components/ui/Toast";

type ProducerRequest = {
  id: number;
  bio: string;
  motivation: string;
  status: "pending" | "approved" | "rejected";
  admin_note: string | null;
  created_at: string;
};

export default function DevenirProducteurPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<{ message: string; variant: "success" | "error" } | null>(null);
  
  const [isProducer, setIsProducer] = useState(false);
  const [request, setRequest] = useState<ProducerRequest | null>(null);
  
  const [bio, setBio] = useState("");
  const [motivation, setMotivation] = useState("");

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/profil/devenir-producteur");
      return;
    }

    async function fetchStatus() {
      try {
        const res = await api.get("/producer/request");
        setIsProducer(res?.is_producer ?? false);
        setRequest(res?.request ?? null);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    void fetchStatus();
  }, [router]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      await api.post("/producer/request", { bio, motivation });
      setToast({ message: "Demande envoyée avec succès !", variant: "success" });
      // Recharger le statut
      const res = await api.get("/producer/request");
      setRequest(res?.request ?? null);
    } catch (e: unknown) {
      setToast({
        message: e instanceof Error ? e.message : "Erreur lors de l'envoi",
        variant: "error",
      });
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) return <div className="container mx-auto px-4 py-16 text-center">Chargement...</div>;

  // Cas 1 : Déjà producteur
  if (isProducer) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl text-center">
        <Card padding="lg">
          <span className="text-5xl block mb-4">🎉</span>
          <h1 className="text-2xl font-bold mb-2">Vous êtes producteur !</h1>
          <p className="text-content-secondary mb-6">
            Vous pouvez désormais soumettre vos instrumentales au catalogue.
          </p>
          <Link href="/profil/soumettre">
            <Button>Soumettre une instrumentale</Button>
          </Link>
        </Card>
      </div>
    );
  }

  // Cas 2 : Demande en attente
  if (request?.status === "pending") {
    return (
      <div className="container mx-auto px-4 py-16 max-w-2xl text-center">
        <Card padding="lg">
          <span className="text-5xl block mb-4">⏳</span>
          <h1 className="text-2xl font-bold mb-2">Demande en attente</h1>
          <p className="text-content-secondary mb-4">
            Votre demande a bien été reçue. Un administrateur va l&apos;examiner prochainement.
          </p>
          <p className="text-xs text-content-secondary">
            Soumise le {new Date(request.created_at).toLocaleDateString("fr-FR")}
          </p>
        </Card>
      </div>
    );
  }

  // Cas 3 : Demande refusée (on affiche le formulaire avec la note)
  return (
    <div className="container mx-auto px-4 py-12 max-w-2xl">
      {toast && <Toast message={toast.message} variant={toast.variant} onClose={() => setToast(null)} />}
      
      <h1 className="text-3xl font-bold mb-2">Devenir Producteur</h1>
      <p className="text-content-secondary mb-8">
        Remplissez ce formulaire pour proposer vos créations. Un administrateur validera votre profil.
      </p>

      {request?.status === "rejected" && (
        <Card padding="md" className="mb-6 border-danger/30 bg-danger/5">
          <p className="text-danger font-medium mb-1">Demande précédente refusée</p>
          {request.admin_note && (
            <p className="text-sm text-content-secondary">Note de l&apos;admin : {request.admin_note}</p>
          )}
        </Card>
      )}

      <Card padding="lg">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium mb-2">Votre parcours / Bio</label>
            <textarea
              required
              rows={4}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              className="w-full p-3 rounded-xl border border-border bg-background focus:border-accent outline-none"
              placeholder="Décrivez votre style musical, vos influences, votre expérience..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Pourquoi souhaitez-vous devenir producteur ?</label>
            <textarea
              required
              rows={4}
              value={motivation}
              onChange={(e) => setMotivation(e.target.value)}
              className="w-full p-3 rounded-xl border border-border bg-background focus:border-accent outline-none"
              placeholder="Expliquez votre motivation..."
            />
          </div>

          <Button type="submit" loading={submitting} className="w-full">
            Envoyer ma demande
          </Button>
        </form>
      </Card>
    </div>
  );
}