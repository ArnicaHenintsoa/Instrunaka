"use client";

import Link from "next/link";
import { Heart, Play } from "lucide-react";

type InstrumentalCardProps = Readonly<{
  id: number;
  title: string;
  producerName?: string;
  coverPath?: string | null;
  mood?: string | null;
  bpm?: number | null;
  price: number;
  exclusivePrice?: number;
}>;

export default function InstrumentalCard({
  id,
  title,
  producerName,
  coverPath,
  mood,
  bpm,
  price,
  exclusivePrice,
}: InstrumentalCardProps) {
  return (
    <Link
      href={`/instrumentales/${id}`}
      className="group block bg-white rounded-2xl overflow-hidden border border-gray-200 hover:border-purple-300 hover:shadow-xl hover:shadow-purple-900/5 transition-all duration-300 hover:-translate-y-1"
    >
      {/* Image / Cover */}
      <div className="relative aspect-square bg-gradient-to-br from-purple-100 to-pink-50 overflow-hidden">
        {coverPath ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={coverPath}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center">
            <span className="text-6xl text-purple-300/50 group-hover:scale-110 transition-transform duration-500">
              ♪
            </span>
          </div>
        )}

        {/* Badge en haut à gauche */}
        <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-md px-2.5 py-1 rounded-md text-[10px] font-bold text-white tracking-wider">
          ALUNA · ÉDITION 01
        </div>

        {/* Bouton favori en haut à droite */}
        <button
          onClick={(e) => e.preventDefault()}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 backdrop-blur-sm flex items-center justify-center text-gray-600 hover:text-red-500 hover:bg-white transition-all"
          aria-label="Ajouter aux favoris"
        >
          <Heart className="w-4 h-4" />
        </button>

        {/* Bouton Play au survol */}
        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="w-14 h-14 rounded-full bg-white/95 backdrop-blur-sm flex items-center justify-center shadow-lg transform scale-90 group-hover:scale-100 transition-transform">
            <Play className="w-6 h-6 text-purple-600 ml-0.5" fill="currentColor" />
          </div>
        </div>
      </div>

      {/* Infos */}
      <div className="p-4">
        <div className="flex items-start justify-between gap-2 mb-1">
          <h3 className="font-semibold text-base text-gray-900 truncate group-hover:text-purple-600 transition-colors">
            {title}
          </h3>
          <span className="font-bold text-sm text-gray-900 shrink-0">
            {price.toLocaleString("fr-FR")} Ar
          </span>
        </div>

        {producerName && (
          <p className="text-xs text-gray-500 mb-3 truncate">par {producerName}</p>
        )}

        {/* Tags */}
        <div className="flex flex-wrap items-center gap-1.5 mb-3">
          {bpm && (
            <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-[10px] font-medium rounded-full">
              {bpm} BPM
            </span>
          )}
          {mood && (
            <span className="px-2 py-0.5 bg-purple-50 text-purple-700 text-[10px] font-medium rounded-full">
              {mood}
            </span>
          )}
          <span className="px-2 py-0.5 bg-gray-100 text-gray-600 text-[10px] font-medium rounded-full">
            NON-EXCLUSIVE
          </span>
        </div>

        {/* Fausse waveform */}
        <div className="flex items-end gap-[1.5px] h-6 mb-2">
          {Array.from({ length: 40 }).map((_, i) => {
            const height = 20 + Math.sin(i * 0.4) * 40 + Math.random() * 20;
            return (
              <div
                key={i}
                className="flex-1 bg-purple-500/60 rounded-full"
                style={{ height: `${Math.min(Math.max(height, 10), 100)}%` }}
              />
            );
          })}
        </div>

        {/* Prix exclusif */}
        {exclusivePrice && (
          <div className="pt-2 border-t border-gray-100 flex items-center justify-between text-xs">
            <span className="text-gray-500">Exclusive</span>
            <span className="font-bold text-gray-900">
              {exclusivePrice.toLocaleString("fr-FR")} Ar
            </span>
          </div>
        )}
      </div>
    </Link>
  );
}