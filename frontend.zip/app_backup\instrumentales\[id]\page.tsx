"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import AudioPlayer from "@/components/instrumental/AudioPlayer";
import OrderModal from "@/components/order/OrderModal";
import Toast from "@/components/ui/Toast";
import ReviewSection from "@/components/instrumental/ReviewSection";
import FollowButton from "@/components/producer/FollowButton";
import AddToPlaylistButton from "@/components/playlist/AddToPlaylistButton";

type InstrumentalDetail = {
  id: number;
  title: string;
  description: string | null;
  cover_path: string | null;
  bpm: number | null;
  musical_key: string | null;
  duration_seconds: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  status: string;
  producer?: { id: number; display_name: string; bio: string | null; verified: boolean } | null;
  genre?: { label: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
  tags?: { id: number; label: string }[];
  files?: { id: number; type: string }[];
  active_promotion?: { discount_percent: number } | null;
};

type OrderPayment = {
  mobile_number: string;
  holder_name: string;
  reference: string;
  amount: number;
};

type PageProps = Readonly<{
  params: Promise<{ id: string }>;
}>;

export default function InstrumentalDetailPage({ params }: PageProps) {
  const { id } = use(params);
  const router = useRouter();

  const [instrumental, setInstrumental] = useState<InstrumentalDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [orderType, setOrderType] = useState<"non_exclusive" | "exclusive" | null>(null);
  const [payment, setPayment] = useState<OrderPayment | null>(null);
  const [orderLoading, setOrderLoading] = useState(false);
  const [toast, setToast] = useState<{ message: string; variant: "success" | "error" } | null>(null);

  const [isFavorited, setIsFavorited] = useState(false);
  const [favoriteLoading, setFavoriteLoading] = useState(false);

  useEffect(() => {
    async function loadInstrumental() {
      try {
        const res = await api.get(`/instrumentals/${id}`);
        setInstrumental(res?.data);
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : "Erreur de chargement");
      } finally {
        setLoading(false);
      }
    }
    void loadInstrumental();
  }, [id]);

  useEffect(() => {
    async function checkFavorite() {
      if (!auth.isAuthenticated() || !instrumental) return;
      try {
        const res = await api.get(`/favorites/${instrumental.id}/check`);
        setIsFavorited(res?.is_favorited ?? false);
      } catch {
        // Silencieux
      }
    }
    void checkFavorite();
  }, [instrumental]);

  const formatDuration = (seconds: number | null) => {
    if (!seconds) return "—";
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  const handleBuy = async (type: "non_exclusive" | "exclusive") => {
    if (!auth.isAuthenticated()) {
      router.push(`/connexion?redirect=/instrumentales/${id}`);
      return;
    }

    setOrderLoading(true);
    setOrderType(type);

    try {
      const res = await api.post("/orders", {
        instrumental_id: instrumental?.id,
        type,
      });
      setPayment(res.payment);
    } catch (e: unknown) {
      setToast({
        message: e instanceof Error ? e.message : "Erreur lors de la création de la commande",
        variant: "error",
      });
      setOrderType(null);
    } finally {
      setOrderLoading(false);
    }
  };

  const closeOrderModal = () => {
    setOrderType(null);
    setPayment(null);
  };

  const handleToggleFavorite = async () => {
    if (!auth.isAuthenticated()) {
      router.push(`/connexion?redirect=/instrumentales/${id}`);
      return;
    }

    setFavoriteLoading(true);
    try {
      if (isFavorited) {
        await api.delete(`/favorites/${instrumental!.id}`);
        setIsFavorited(false);
      } else {
        await api.post(`/favorites/${instrumental!.id}`);
        setIsFavorited(true);
      }
    } catch (e: unknown) {
      setToast({
        message: e instanceof Error ? e.message : "Erreur",
        variant: "error",
      });
    } finally {
      setFavoriteLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-12">
        <p className="text-content-secondary">Chargement...</p>
      </div>
    );
  }

  if (error || !instrumental) {
    return (
      <div className="container mx-auto px-4 py-12">
        <Card padding="lg" className="text-center max-w-md mx-auto">
          <p className="text-danger mb-4">
            {error || "Cette instrumentale n'est pas disponible."}
          </p>
          <Link href="/catalogue">
            <Button variant="secondary">← Retour au catalogue</Button>
          </Link>
        </Card>
      </div>
    );
  }

  const hasPreview = instrumental.files?.some((f) => f.type === "preview");
  const previewUrl = `${process.env.NEXT_PUBLIC_API_URL}/instrumentals/${instrumental.id}/preview`;

  return (
    <div className="container mx-auto px-4 py-8">
      {toast && (
        <Toast
          message={toast.message}
          variant={toast.variant}
          onClose={() => setToast(null)}
        />
      )}

      <Link
        href="/catalogue"
        className="inline-flex items-center gap-2 text-sm text-content-secondary hover:text-accent mb-6 transition-colors"
      >
        ← Retour au catalogue
      </Link>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="aspect-square bg-gradient-to-br from-accent-light to-background-secondary rounded-2xl overflow-hidden border border-border">
            {instrumental.cover_path ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={instrumental.cover_path}
                alt={instrumental.title}
                className="w-full h-full object-cover"
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center">
                <span className="text-7xl text-accent/40">♪</span>
              </div>
            )}
          </div>

          {instrumental.tags && instrumental.tags.length > 0 && (
            <Card padding="md" className="mt-4">
              <h3 className="text-sm font-medium mb-3">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {instrumental.tags.map((tag) => (
                  <Badge key={tag.id} variant="default">
                    {tag.label}
                  </Badge>
                ))}
              </div>
            </Card>
          )}
        </div>

        <div className="lg:col-span-2">
          <div className="mb-6">
            <div className="flex items-start justify-between gap-3 mb-2">
              <div className="flex items-center gap-3 flex-wrap">
                <h1 className="text-3xl font-bold">{instrumental.title}</h1>
                {instrumental.active_promotion && (
                  <Badge variant="accent">
                    🎁 -{instrumental.active_promotion.discount_percent}%
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <AddToPlaylistButton instrumentalId={instrumental.id} size="md" />
                <button
                  onClick={handleToggleFavorite}
                  disabled={favoriteLoading}
                  className={`px-4 py-2 rounded-xl text-sm font-medium transition-colors disabled:opacity-50 ${
                    isFavorited
                      ? "bg-accent text-white hover:bg-accent-hover"
                      : "bg-background-secondary text-content hover:bg-accent-light"
                  }`}
                  title={isFavorited ? "Retirer des favoris" : "Ajouter aux favoris"}
                >
                  {isFavorited ? "⭐ Favori" : "☆ Favori"}
                </button>
              </div>
            </div>
            {instrumental.producer && (
              <div className="flex items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-content-secondary">par</span>
                  <Link
                    href={`/producteurs/${instrumental.producer.id}`}
                    className="text-accent hover:underline font-medium"
                  >
                    {instrumental.producer.display_name}
                  </Link>
                  {instrumental.producer.verified && (
                    <span className="text-accent text-sm" title="Producteur vérifié">
                      ✓
                    </span>
                  )}
                </div>
                <FollowButton producerId={instrumental.producer.id} size="sm" />
              </div>
            )}
          </div>

          {hasPreview ? (
            <div className="mb-6">
              <AudioPlayer src={previewUrl} title="Écouter un aperçu" />
            </div>
          ) : (
            <Card padding="md" className="mb-6 text-center">
              <p className="text-sm text-content-secondary">
                Aucun aperçu disponible pour le moment.
              </p>
            </Card>
          )}

          <Card padding="lg" className="mb-6">
            <h2 className="font-semibold mb-4">Caractéristiques</h2>
            <dl className="grid grid-cols-2 gap-4 text-sm">
              {instrumental.mood && (
                <div>
                  <dt className="text-content-secondary">Humeur</dt>
                  <dd className="font-medium">{instrumental.mood.label}</dd>
                </div>
              )}
              {instrumental.rhythm && (
                <div>
                  <dt className="text-content-secondary">Rythme</dt>
                  <dd className="font-medium">{instrumental.rhythm.label}</dd>
                </div>
              )}
              {instrumental.genre && (
                <div>
                  <dt className="text-content-secondary">Genre</dt>
                  <dd className="font-medium">{instrumental.genre.label}</dd>
                </div>
              )}
              {instrumental.bpm != null && (
                <div>
                  <dt className="text-content-secondary">BPM</dt>
                  <dd className="font-medium">{instrumental.bpm}</dd>
                </div>
              )}
              {instrumental.musical_key && (
                <div>
                  <dt className="text-content-secondary">Tonalité</dt>
                  <dd className="font-medium">{instrumental.musical_key}</dd>
                </div>
              )}
              {instrumental.duration_seconds != null && (
                <div>
                  <dt className="text-content-secondary">Durée</dt>
                  <dd className="font-medium">
                    {formatDuration(instrumental.duration_seconds)}
                  </dd>
                </div>
              )}
            </dl>

            {instrumental.description && (
              <div className="mt-6 pt-6 border-t border-border">
                <h3 className="text-sm font-medium mb-2">Description</h3>
                <p className="text-sm text-content-secondary">
                  {instrumental.description}
                </p>
              </div>
            )}
          </Card>

          <Card padding="lg">
            <h2 className="font-semibold mb-4">Acheter cette instrumentale</h2>

            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 border border-border rounded-xl">
                <div>
                  <p className="font-medium">Licence non exclusive</p>
                  <p className="text-xs text-content-secondary mt-0.5">
                    MP3 + WAV · L&apos;instrumentale reste disponible
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold">
                    {instrumental.non_exclusive_price.toLocaleString("fr-FR")} Ar
                  </span>
                  <Button
                    size="sm"
                    loading={orderLoading && orderType === "non_exclusive"}
                    onClick={() => handleBuy("non_exclusive")}
                  >
                    Télécharger
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border-2 border-accent rounded-xl bg-accent-light/30">
                <div>
                  <div className="flex items-center gap-2">
                    <p className="font-medium">Licence exclusive</p>
                    <Badge variant="accent">Retiré du catalogue</Badge>
                  </div>
                  <p className="text-xs text-content-secondary mt-0.5">
                    MP3 + WAV · Vous devenez l&apos;unique propriétaire
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-bold">
                    {instrumental.exclusive_price.toLocaleString("fr-FR")} Ar
                  </span>
                  <Button
                    size="sm"
                    loading={orderLoading && orderType === "exclusive"}
                    onClick={() => handleBuy("exclusive")}
                  >
                    Acheter
                  </Button>
                </div>
              </div>
            </div>

            <p className="text-xs text-content-secondary mt-4">
              💡 Le paiement se fait par Mobile Banking, suivi d&apos;une
              validation manuelle par notre équipe.
            </p>
          </Card>

          <ReviewSection instrumentalId={instrumental.id} />
        </div>
      </div>

      <OrderModal
        isOpen={!!payment}
        onClose={closeOrderModal}
        payment={payment}
        orderType={orderType ?? "non_exclusive"}
        instrumentalTitle={instrumental.title}
      />
    </div>
  );
}