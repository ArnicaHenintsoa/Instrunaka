"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Toast from "@/components/ui/Toast";

type InstrumentalFile = {
  id: number;
  type: string;
  path: string;
  url?: string;
};

type Instrumental = {
  id: number;
  title: string;
  description: string | null;
  bpm: number | null;
  musical_key: string | null;
  duration_seconds: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  status: string;
  created_at: string;
  producer?: {
    user?: { name: string; email: string } | null;
  } | null;
  genre?: { label: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
  files?: InstrumentalFile[];
};

export default function AdminSoumissionsPage() {
  const router = useRouter();
  const [instrumentals, setInstrumentals] = useState<Instrumental[]>([]);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<{ message: string; variant: "success" | "error" } | null>(null);

  const [rejectingId, setRejectingId] = useState<number | null>(null);
  const [adminNote, setAdminNote] = useState("");

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/admin/soumissions");
      return;
    }

    async function loadSubmissions() {
      try {
        const res = await api.get("/admin/instrumentals");
        setInstrumentals(res?.data ?? []);
      } catch (e: unknown) {
        setToast({
          message: e instanceof Error ? e.message : "Erreur de chargement",
          variant: "error",
        });
      } finally {
        setLoading(false);
      }
    }
    void loadSubmissions();
  }, [router]);

  const handleValidate = async (id: number) => {
    try {
      await api.post(`/admin/instrumentals/${id}/validate`);
      setToast({ message: "Instrumentale validée et publiée !", variant: "success" });
      setInstrumentals((prev) => prev.filter((i) => i.id !== id));
    } catch (e: unknown) {
      setToast({
        message: e instanceof Error ? e.message : "Erreur lors de la validation",
        variant: "error",
      });
    }
  };

  const handleReject = async (id: number) => {
    if (!adminNote.trim()) {
      setToast({ message: "Veuillez saisir une note pour le refus.", variant: "error" });
      return;
    }

    try {
      await api.post(`/admin/instrumentals/${id}/reject`, { admin_note: adminNote });
      setToast({ message: "Instrumentale refusée.", variant: "success" });
      setInstrumentals((prev) => prev.filter((i) => i.id !== id));
      setRejectingId(null);
      setAdminNote("");
    } catch (e: unknown) {
      setToast({
        message: e instanceof Error ? e.message : "Erreur lors du refus",
        variant: "error",
      });
    }
  };

  if (loading) {
    return <div className="container mx-auto px-4 py-16 text-center">Chargement...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {toast && <Toast message={toast.message} variant={toast.variant} onClose={() => setToast(null)} />}

      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Soumissions en attente</h1>
        <p className="text-content-secondary">
          Validez ou refusez les instrumentales proposées par les producteurs.
        </p>
      </div>

      {instrumentals.length === 0 && (
        <Card padding="lg" className="text-center py-16">
          <span className="text-5xl block mb-4">📭</span>
          <p className="text-content-secondary">Aucune soumission en attente.</p>
        </Card>
      )}

      <div className="space-y-6">
        {instrumentals.map((inst) => (
          <Card key={inst.id} padding="lg">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h2 className="text-xl font-semibold">{inst.title}</h2>
                <p className="text-sm text-content-secondary">
                  par {inst.producer?.user?.name ?? "Producteur inconnu"} ({inst.producer?.user?.email})
                </p>
                <p className="text-xs text-content-secondary mt-1">
                  Soumise le {new Date(inst.created_at).toLocaleDateString("fr-FR")}
                </p>
              </div>
              <Badge variant="warning">En attente</Badge>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4 text-sm">
              <div>
                <span className="text-content-secondary">BPM :</span> {inst.bpm ?? "—"}
              </div>
              <div>
                <span className="text-content-secondary">Tonalité :</span> {inst.musical_key ?? "—"}
              </div>
              <div>
                <span className="text-content-secondary">Durée :</span> {inst.duration_seconds ?? "—"} s
              </div>
              <div>
                <span className="text-content-secondary">Prix :</span> {inst.non_exclusive_price} Ar / {inst.exclusive_price} Ar
              </div>
            </div>

            {inst.description && (
              <p className="text-sm text-content-secondary mb-4 bg-background-secondary p-3 rounded-lg">
                {inst.description}
              </p>
            )}

          {/* Fichiers audio */}
{inst.files && inst.files.length > 0 && (
  <div className="mb-4 pt-4 border-t border-border space-y-3">
    <h4 className="text-sm font-medium mb-2">🎵 Fichiers audio</h4>
    {inst.files.map((file) => {
      const fileUrl = file.url || `${process.env.NEXT_PUBLIC_API_URL?.replace('/api', '')}/storage/${file.path}`;
      return (
        <div key={file.id} className="bg-background-secondary p-3 rounded-lg">
          <div className="flex items-center gap-3 mb-2">
            <span className="text-xs font-mono text-content-secondary uppercase w-16 shrink-0">
              {file.type}
            </span>
            <a
              href={fileUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-accent hover:underline text-sm flex-1"
            >
              {file.type === "cover" ? "🖼️ Voir l'image" : `⬇️ Télécharger ${file.type.toUpperCase()}`}
            </a>
          </div>

          {/* Si c'est une cover, on affiche l'image */}
          {file.type === "cover" && (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={fileUrl}
              alt="Cover"
              className="w-full max-w-xs rounded-lg border border-border"
            />
          )}

          {/* Si c'est un preview, on affiche le player */}
          {file.type === "preview" && (
            <audio
              controls
              preload="metadata"
              className="w-full h-10"
              src={fileUrl}
            >
              Votre navigateur ne supporte pas l&apos;audio.
            </audio>
          )}

          {/* Si c'est MP3 ou WAV, on propose un player aussi */}
          {(file.type === "mp3" || file.type === "wav") && (
            <audio
              controls
              preload="metadata"
              className="w-full h-10"
              src={fileUrl}
            >
              Votre navigateur ne supporte pas l&apos;audio.
            </audio>
          )}
        </div>
      );
    })}
  </div>
)}

            <div className="flex gap-3 pt-4 border-t border-border">
              {rejectingId === inst.id ? (
                <div className="w-full space-y-3">
                  <textarea
                    rows={3}
                    value={adminNote}
                    onChange={(e) => setAdminNote(e.target.value)}
                    placeholder="Raison du refus (obligatoire)..."
                    className="w-full p-3 rounded-xl border border-border bg-background focus:border-accent outline-none text-sm"
                  />
                  <div className="flex gap-2">
                    <Button variant="danger" size="sm" onClick={() => handleReject(inst.id)}>
                      Confirmer le refus
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => { setRejectingId(null); setAdminNote(""); }}>
                      Annuler
                    </Button>
                  </div>
                </div>
              ) : (
                <>
                  <Button variant="primary" onClick={() => handleValidate(inst.id)}>
                    ✅ Valider et publier
                  </Button>
                  <Button variant="secondary" onClick={() => setRejectingId(inst.id)}>
                    ❌ Refuser
                  </Button>
                </>
              )}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}