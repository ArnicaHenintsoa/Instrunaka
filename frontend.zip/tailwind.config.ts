import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        // Fonds
        background: {
          DEFAULT: "#F8F7FF",   // Nouveau fond de page de la maquette
          secondary: "#F5F5F5",
          tertiary: "#FAFAFA",
        },
        // Bordures
        border: {
          DEFAULT: "#E5E5E5",
          light: "#F0F0F0",
        },
        // Texte
        content: {
          DEFAULT: "#0F0B24",     // Bleu nuit presque noir
          secondary: "#6B6785",   // Gris-violet
        },
        // Couleur d'accent principale (violet Instrunaka)
        accent: {
          DEFAULT: "#7C5CE8",     // Violet principal de la maquette
          hover: "#5B3EC0",       // Violet plus foncé pour le hover
          light: "#EDE9FE",       // Violet clair / lavande
          lighter: "#F5F3FF",
        },
        // Couleur sombre (player, footer)
        dark: "#0F0B24",
        // Couleurs sémantiques
        success: "#10B981",
        warning: "#F59E0B",
        danger: "#EF4444",
      },
      fontFamily: {
        sans: ["var(--font-manrope)", "system-ui", "sans-serif"],
      },
      borderRadius: {
        xl: "0.75rem",
        "2xl": "1rem",
        "3xl": "1.5rem",
        "4xl": "2rem",      // Nouveau pour le hero et les cartes
        "5xl": "2.5rem",
      },
      boxShadow: {
        soft: "0 2px 12px -2px rgb(124 92 232 / 0.08)",
        card: "0 4px 24px -4px rgb(124 92 232 / 0.10)",
        "card-hover": "0 12px 32px -8px rgb(124 92 232 / 0.15)",
        glass: "0 8px 32px 0 rgba(31, 38, 135, 0.07)", // Pour le hero
      },
    },
  },
  plugins: [],
};

export default config;