"use client";

import { useEffect, useState } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import { api, auth } from "@/lib/api";

type User = {
  id: number;
  name: string;
  email: string;
  is_admin: boolean;
  role: string;
};

export default function AdminLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  const router = useRouter();
  const pathname = usePathname();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=" + pathname);
      return;
    }

    async function loadUser() {
      try {
        const res = await api.get("/auth/me");
        if (!res?.user?.is_admin) {
          router.push("/");
          return;
        }
        setUser(res.user);
      } catch {
        auth.removeToken();
        router.push("/connexion");
      } finally {
        setLoading(false);
      }
    }
    void loadUser();
  }, [router, pathname]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <p className="text-content-secondary">Vérification des droits...</p>
      </div>
    );
  }

  if (!user) return null;

  const isActive = (href: string, exact = false) =>
    exact ? pathname === href : pathname.startsWith(href);

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 text-sm text-content-secondary mb-2">
              <span className="px-2 py-0.5 bg-accent-light text-accent rounded-full font-medium">
                Administrateur
              </span>
              <span>·</span>
              <span>{user.name}</span>
            </div>
            <h1 className="text-3xl font-bold">Administration</h1>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <Link
              href="/admin"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin", true)
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              📊 Tableau de bord
            </Link>
            <Link
              href="/admin/commandes"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/commandes")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              📋 Commandes
            </Link>
            <Link
              href="/admin/demandes-producteur"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/demandes-producteur")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              🎵 Producteurs
            </Link>
            <Link
              href="/admin/soumissions"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/soumissions")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              📥 Soumissions
            </Link>
            <Link
              href="/admin/catalogue"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/catalogue")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              📚 Catalogue
            </Link>
            <Link
              href="/admin/utilisateurs"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/utilisateurs")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              👥 Utilisateurs
            </Link>
            <Link
              href="/admin/codes-promo"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/codes-promo")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              🎟️ Codes promo
            </Link>
            <Link
              href="/admin/packs"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/packs")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              📦 Packs
            </Link>
            <Link
              href="/admin/promotions"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/promotions")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              🎁 Promotions
            </Link>
            <Link
              href="/admin/avis"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/avis")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              💬 Avis
            </Link>
            <Link
              href="/admin/historique"
              className={`text-sm px-3 py-2 rounded-lg transition-colors ${
                isActive("/admin/historique")
                  ? "bg-accent text-white"
                  : "bg-background-secondary hover:bg-accent-light"
              }`}
            >
              🕵️ Historique
            </Link>
            <Link
              href="/"
              className="text-sm text-content-secondary hover:text-accent transition-colors px-3 py-2"
            >
              ← Retour au site
            </Link>
          </div>
        </div>
      </div>

      {children}
    </div>
  );
}