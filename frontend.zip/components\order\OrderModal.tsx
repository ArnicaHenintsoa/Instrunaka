"use client";

import { useState } from "react";
import Modal from "@/components/ui/Modal";
import Button from "@/components/ui/Button";
import { QRCodeSVG } from "qrcode.react";

type OrderPaymentInfo = {
  mobile_number: string;
  holder_name: string;
  reference: string;
  amount: number;
};

type OrderModalProps = Readonly<{
  isOpen: boolean;
  onClose: () => void;
  payment: OrderPaymentInfo | null;
  orderType: "non_exclusive" | "exclusive";
  instrumentalTitle: string;
}>;

export default function OrderModal({
  isOpen,
  onClose,
  payment,
  orderType,
  instrumentalTitle,
}: OrderModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyReference = async () => {
    if (!payment) return;
    try {
      await navigator.clipboard.writeText(payment.reference);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch {}
  };

  if (!payment) return null;

  // Le montant affiché est DÉJÀ le montant final renvoyé par le serveur
  const finalAmount = payment.amount;
  const cleanNumber = payment.mobile_number.replace(/\s/g, "");

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="Finaliser votre achat" maxWidth="lg">
      <div className="flex flex-col md:flex-row gap-8">
        
        {/* GAUCHE : Paiement & QR */}
        <div className="flex-1 space-y-4">
          <div className="bg-background-secondary rounded-xl p-4">
            <p className="text-sm text-content-secondary mb-1">Vous achetez</p>
            <p className="font-semibold text-lg">{instrumentalTitle}</p>
            <p className="text-xs text-content-secondary capitalize mt-1">
              Licence {orderType === "exclusive" ? "exclusive" : "non exclusive"}
            </p>
          </div>

          <div className="border border-border rounded-xl p-4 flex flex-col items-center bg-white">
            <QRCodeSVG
              value={`tel:${cleanNumber}`}
              size={140}
              bgColor={"#ffffff"}
              fgColor={"#7c3aed"}
              level={"L"}
            />
            <p className="text-xs text-content-secondary mt-4 mb-1">Ou envoyez au numéro :</p>
            <p className="text-lg font-bold tracking-wide">{payment.mobile_number}</p>
            <p className="text-xs text-content-secondary">{payment.holder_name}</p>
          </div>
        </div>

        {/* DROITE : Montant & Référence */}
        <div className="flex-1 space-y-4 flex flex-col justify-between">
          <div className="space-y-4">

            {/* Montant final (déjà calculé par le serveur) */}
            <div className="border border-border rounded-xl p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Montant à envoyer</span>
                <span className="text-xl font-bold text-accent">
                  {finalAmount.toLocaleString("fr-FR")} Ar
                </span>
              </div>
            </div>

            {/* Référence */}
            <div className="border-2 border-accent rounded-xl p-4 bg-accent-light/30">
              <div className="flex items-center justify-between mb-1">
                <span className="text-xs font-bold uppercase text-accent">Référence</span>
                <button onClick={handleCopyReference} className="text-xs text-accent hover:underline font-medium">
                  {copied ? "✓ Copié" : "Copier"}
                </button>
              </div>
              <p className="font-mono text-base font-bold tracking-wider text-content whitespace-nowrap overflow-x-auto">
                {payment.reference}
              </p>
            </div>
          </div>

          {/* Actions */}
          <div className="flex gap-2 pt-2">
            <Button variant="secondary" onClick={onClose} className="flex-1">
              Fermer
            </Button>
            <Button onClick={() => { onClose(); window.location.href = "/mes-achats"; }} className="flex-1">
              Mes achats
            </Button>
          </div>
        </div>
      </div>
    </Modal>
  );
}