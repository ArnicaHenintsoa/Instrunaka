"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";

type Order = {
  id: number;
  reference: string;
  type: "non_exclusive" | "exclusive";
  amount: number;
  status: "pending" | "validated" | "rejected" | "cancelled";
  instrumental: { id: number; title: string } | null;
  validated_at: string | null;
  created_at: string;
};

type Meta = {
  current_page: number;
  per_page: number;
  total: number;
  last_page: number;
};

const statusBadge: Record<
  string,
  { variant: "warning" | "success" | "danger" | "default"; label: string }
> = {
  pending: { variant: "warning", label: "En attente" },
  validated: { variant: "success", label: "Validée" },
  rejected: { variant: "danger", label: "Refusée" },
  cancelled: { variant: "default", label: "Annulée" },
};

export default function MesAchatsPage() {
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [meta, setMeta] = useState<Meta | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/mes-achats");
      return;
    }

    async function loadOrders() {
      try {
        const res = await api.get("/orders");
        setOrders(res?.data ?? []);
        setMeta(res?.meta ?? null);
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : "Erreur de chargement");
      } finally {
        setLoading(false);
      }
    }
    void loadOrders();
  }, [router]);

  const handleDownload = async (
    orderId: number,
    fileType: "mp3" | "wav",
    orderTitle: string
  ) => {
    try {
      const token = auth.getToken();
      const apiUrl = process.env.NEXT_PUBLIC_API_URL;

      const response = await fetch(
        `${apiUrl}/downloads/${orderId}/${fileType}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: "application/json",
          },
        }
      );

      if (!response.ok) {
        const data = await response.json().catch(() => null);
        throw new Error(data?.message || "Erreur de téléchargement");
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `${orderTitle}.${fileType}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (e) {
      alert(
        e instanceof Error ? e.message : "Erreur lors du téléchargement"
      );
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <p className="text-content-secondary">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <h1 className="text-3xl font-bold mb-2">Mes achats</h1>
      <p className="text-content-secondary mb-8">
        Historique de vos commandes et accès aux téléchargements.
      </p>

      {error && (
        <Card padding="lg" className="mb-6">
          <p className="text-danger">{error}</p>
        </Card>
      )}

      {orders.length === 0 && !error && (
        <Card padding="lg" className="text-center py-12">
          <p className="text-content-secondary mb-4">
            Vous n&apos;avez pas encore d&apos;achat.
          </p>
          <Link href="/catalogue">
            <Button>Explorer le catalogue</Button>
          </Link>
        </Card>
      )}

      {orders.length > 0 && (
        <div className="space-y-3">
          {orders.map((order) => {
            const badge = statusBadge[order.status] ?? statusBadge.pending;
            const isDownloadable = order.status === "validated";
            const instrumentalTitle = order.instrumental?.title;

            return (
              <Card key={order.id} padding="md">
                <div className="flex items-start justify-between gap-4 flex-wrap">
                  <div className="flex-1 min-w-[200px]">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <h3 className="font-semibold">
                        {instrumentalTitle ?? "Instrumentale supprimée"}
                      </h3>
                      <Badge variant={badge.variant}>{badge.label}</Badge>
                      {order.type === "exclusive" && (
                        <Badge variant="accent">Exclusif</Badge>
                      )}
                    </div>

                    <div className="grid grid-cols-2 gap-x-6 gap-y-1 text-xs text-content-secondary">
                      <div>
                        <span className="font-mono">{order.reference}</span>
                      </div>
                      <div>
                        {order.type === "exclusive"
                          ? "Licence exclusive"
                          : "Licence non exclusive"}
                      </div>
                      <div>
                        {new Date(order.created_at).toLocaleDateString(
                          "fr-FR",
                          {
                            day: "2-digit",
                            month: "long",
                            year: "numeric",
                          }
                        )}
                      </div>
                      <div className="font-semibold text-content">
                        {order.amount.toLocaleString("fr-FR")} Ar
                      </div>
                    </div>
                  </div>

                  <div className="shrink-0">
                    {isDownloadable && instrumentalTitle && (
                      <div className="flex flex-col gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() =>
                            handleDownload(order.id, "mp3", instrumentalTitle)
                          }
                        >
                          ⬇ MP3
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() =>
                            handleDownload(order.id, "wav", instrumentalTitle)
                          }
                        >
                          ⬇ WAV
                        </Button>
                      </div>
                    )}
                    {order.status === "pending" && (
                      <p className="text-xs text-content-secondary text-right max-w-[120px]">
                        En attente de validation par un administrateur
                      </p>
                    )}
                    {order.status === "rejected" && (
                      <p className="text-xs text-danger text-right max-w-[120px]">
                        Paiement refusé
                      </p>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}

      {meta && meta.last_page > 1 && (
        <p className="text-center text-sm text-content-secondary mt-8">
          Page {meta.current_page} sur {meta.last_page}
        </p>
      )}
    </div>
  );
}