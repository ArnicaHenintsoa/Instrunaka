"use client";

import { Play, Pause } from "lucide-react";
import { usePlayer } from "@/context/PlayerContext";

type Track = {
  id: number;
  title: string;
  producerName?: string;
  coverPath?: string | null;
  previewUrl: string;
  duration?: number;
};

type PlayButtonProps = Readonly<{
  track: Track;
  queue?: Track[];
  size?: "sm" | "md";
}>;

export default function PlayButton({ track, queue, size = "md" }: PlayButtonProps) {
  const { currentTrack, isPlaying, playTrack } = usePlayer();
  const isCurrent = currentTrack?.id === track.id;
  const isCurrentlyPlaying = isCurrent && isPlaying;

  const sizeClasses = size === "sm" ? "w-8 h-8" : "w-10 h-10";
  const iconClasses = size === "sm" ? "w-3 h-3" : "w-4 h-4";

  return (
    <button
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        playTrack(track, queue);
      }}
      className={`${sizeClasses} rounded-full bg-accent text-white flex items-center justify-center hover:bg-accent-hover transition-colors shrink-0`}
      aria-label={isCurrentlyPlaying ? "Pause" : "Lecture"}
    >
      {isCurrentlyPlaying ? (
        <Pause className={iconClasses} fill="currentColor" />
      ) : (
        <Play className={`${iconClasses} ml-0.5`} fill="currentColor" />
      )}
    </button>
  );
}