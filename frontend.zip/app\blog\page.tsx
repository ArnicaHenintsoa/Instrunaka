import Link from "next/link";
import PageContainer from "@/components/layout/PageContainer";
import PageHeader from "@/components/layout/PageHeader";
import { PenLine, ArrowRight } from "lucide-react";

export default function BlogPage() {
  return (
    <PageContainer>
      <PageHeader 
        label="BLOG" 
        title="Le journal d'Instrunaka" 
        subtitle="Actualités, tutoriels et interviews de la scène musicale malgache."
      />

      <div className="bg-gradient-to-br from-accent-light to-[#E0D8FD] rounded-3xl p-8 md:p-16 text-center mb-16 relative overflow-hidden">
        <div className="relative z-10 flex flex-col items-center">
          <div className="w-20 h-20 rounded-full bg-white/50 backdrop-blur-sm flex items-center justify-center mb-6 shadow-sm">
            <PenLine className="w-10 h-10 text-accent" />
          </div>
          <h2 className="text-2xl md:text-3xl font-semibold text-content mb-4">
            Les articles arrivent bientôt
          </h2>
          <p className="text-content-secondary max-w-lg mx-auto mb-8 text-base">
            On te prépare des tutoriels, des interviews de producteurs et des conseils pour tes projets musicaux. Reviens vite !
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Link href="/catalogue" className="px-6 py-3 rounded-full bg-accent text-white font-semibold hover:bg-accent-hover transition-colors shadow-lg shadow-accent/20">
              Explorer le catalogue
            </Link>
            <Link href="/producteurs" className="px-6 py-3 rounded-full bg-white text-content font-semibold hover:bg-gray-50 transition-colors flex items-center gap-2">
              Voir les producteurs <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </div>
    </PageContainer>
  );
}