import type { Metadata } from "next";
import { Suspense } from "react";
import "./globals.css";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import LogoutToast from "@/components/layout/LogoutToast";
import { PLATFORM } from "@/lib/config";

export const metadata: Metadata = {
  title: `${PLATFORM.fullName} — ${PLATFORM.tagline}`,
  description: PLATFORM.description,
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-background text-content flex flex-col">
        <Suspense fallback={null}>
          <LogoutToast />
        </Suspense>
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  );
}