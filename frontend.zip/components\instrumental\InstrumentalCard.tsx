"use client";

import Link from "next/link";
import { Heart, Play, Pause, Download } from "lucide-react";
import { usePlayer } from "@/context/PlayerContext";
import { useAuthModal } from "@/context/AuthModalContext";
import { auth } from "@/lib/api";
import InstrumentalWaveform from "./InstrumentalWaveform";
import CoverImage from "@/components/ui/CoverImage";

type InstrumentalCardProps = Readonly<{
  id: number;
  title: string;
  producerName?: string;
  coverPath?: string | null;
  mood?: string | null;
  genre?: string | null;
  bpm?: number | null;
  musicalKey?: string | null;
  price: number;
  exclusivePrice?: number;
}>;

export default function InstrumentalCard({
  id, title, producerName, coverPath, mood, genre, bpm, musicalKey,
}: InstrumentalCardProps) {
  const { currentTrack, isPlaying, playTrack } = usePlayer();
  const { openAuthModal } = useAuthModal();
  
  const previewUrl = `${process.env.NEXT_PUBLIC_API_URL}/instrumentals/${id}/preview`;
  const track = { id, title, producerName, coverPath, previewUrl };

  const isCurrent = currentTrack?.id === id;
  const isCurrentlyPlaying = isCurrent && isPlaying;

  const handlePlay = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    playTrack(track, [track]);
  };

  const handleBuy = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!auth.isAuthenticated()) {
      openAuthModal({ id, title, coverPath: coverPath || null, price: 0 });
    } else {
      window.location.href = `/instrumentales/${id}`;
    }
  };

  return (
    <div className="group relative bg-white rounded-[28px] p-3 border border-border hover:border-accent/30 hover:shadow-xl hover:shadow-accent/10 transition-all duration-300 flex flex-col">
      
      <Link href={`/instrumentales/${id}`} className="block relative aspect-square overflow-hidden rounded-[20px] bg-background-secondary">
        <CoverImage src={coverPath} alt={title} id={id} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
        
        <div className="absolute top-3 left-3 bg-dark/60 backdrop-blur-md px-3 py-1 rounded-full text-[11px] font-medium text-white tracking-wide">
          {genre || mood || "Instrumental"}
        </div>

        <button onClick={(e) => { e.preventDefault(); e.stopPropagation(); }} className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/80 backdrop-blur-sm flex items-center justify-center text-content hover:text-red-500 hover:bg-white transition-all shadow-sm">
          <Heart className="w-4 h-4" />
        </button>

        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <button onClick={handlePlay} className="w-14 h-14 rounded-full bg-white text-accent flex items-center justify-center shadow-xl transform scale-90 group-hover:scale-100 transition-transform">
            {isCurrentlyPlaying ? <Pause className="w-6 h-6" fill="currentColor" /> : <Play className="w-6 h-6 ml-1" fill="currentColor" />}
          </button>
        </div>
      </Link>

      <div className="pt-4 flex flex-col flex-1">
        <div className="flex items-start justify-between gap-2 mb-1">
          <Link href={`/instrumentales/${id}`}>
            <h3 className="font-semibold text-base text-content truncate hover:text-accent transition-colors">{title}</h3>
          </Link>
        </div>

        {producerName && <p className="text-xs text-content-secondary mb-3 truncate">par {producerName}</p>}

        <InstrumentalWaveform id={id} />

        <div className="mt-auto pt-3 border-t border-border flex items-center justify-between gap-2">
          <div className="text-[11px] font-medium text-content-secondary">
            {bpm ? `${bpm} BPM` : "—"} {musicalKey ? `· ${musicalKey}` : ""}
          </div>
          <button
            onClick={handleBuy}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-dark text-white text-xs font-semibold hover:bg-accent transition-colors"
          >
            <Download className="w-3 h-3" />
            Acheter
          </button>
        </div>
      </div>
    </div>
  );
}