"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import { ArrowRight, MapPin, Check } from "lucide-react";
import HeroCarousel from "@/components/home/HeroCarousel";
import HeroContent from "@/components/home/HeroContent";
import InstrumentalCard from "@/components/instrumental/InstrumentalCard";
import InstrumentalRow from "@/components/instrumental/InstrumentalRow";

type Instrumental = {
  id: number;
  title: string;
  cover_path: string | null;
  bpm: number | null;
  duration_seconds: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  producer?: { display_name: string } | null;
  mood?: { label: string } | null;
  genre?: { label: string } | null;
  musical_key?: string | null;
};

type Stats = { instrumentals: number; producers: number; downloads: number; };

const MIN_BEATS_FOR_STATS = 50;

export default function HomePage() {
  const [instrumentals, setInstrumentals] = useState<Instrumental[]>([]);
  const [stats, setStats] = useState<Stats>({ instrumentals: 0, producers: 0, downloads: 0 });
  const [loading, setLoading] = useState(true);
  const [featuredBeat, setFeaturedBeat] = useState<Instrumental | null>(null);

  useEffect(() => {
    async function loadData() {
      try {
        const [instrumentsRes, statsRes] = await Promise.all([
          api.get("/instrumentals?sort=recent"),
          api.get("/stats"),
        ]);
        
        const apiBeats = instrumentsRes?.data ?? [];
        
        setInstrumentals(apiBeats);
        if (statsRes) setStats(statsRes);
        
        if (apiBeats.length > 0) {
          setFeaturedBeat(apiBeats[0]);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    void loadData();
  }, []);

  const trending = instrumentals.slice(0, 4);
  const recent = instrumentals;

  // Skeleton de chargement
  if (loading) {
    return (
      <div className="bg-background min-h-screen pb-20">
        <section className="w-full px-2 md:px-4 pt-2 mb-16 max-w-[1600px] mx-auto">
          <div className="relative rounded-[32px] overflow-hidden h-[calc(100vh-16px)] min-h-[680px] bg-dark animate-pulse">
             <div className="absolute inset-0 flex flex-col items-center justify-center gap-6">
                <div className="w-40 h-10 bg-white/10 rounded-full" />
                <div className="w-3/4 max-w-3xl h-32 bg-white/10 rounded-3xl" />
                <div className="w-1/2 max-w-md h-8 bg-white/10 rounded-xl" />
                <div className="w-full max-w-2xl h-20 bg-white/10 rounded-3xl mt-8" />
             </div>
          </div>
        </section>
      </div>
    );
  }

  return (
    <div className="bg-background min-h-screen pb-20">
      
      {/* ================= HERO ================= */}
      <section className="w-full px-2 md:px-4 pt-2 mb-16 max-w-[1600px] mx-auto">
        <div className="relative rounded-[32px] overflow-hidden h-[calc(100vh-16px)] min-h-[680px] flex flex-col justify-center bg-dark">
          
          <HeroCarousel />
          <HeroContent featuredBeat={featuredBeat} />

          <div className="absolute bottom-0 left-0 w-full h-24 flex items-end justify-center gap-1 opacity-20 pointer-events-none z-0">
            {[...Array(60)].map((_, i) => (
              <div 
                key={i} 
                className="w-1.5 bg-white rounded-t-sm eq-bar" 
                style={{ 
                  height: `${20 + Math.sin(i * 0.5) * 30 + (i * 7) % 40}%`,
                  animationDelay: `${i * 0.05}s` 
                }} 
              />
            ))}
          </div>

        </div>
      </section>

      {/* ================= BANDE D'ARGUMENTS ================= */}
      <section className="container mx-auto px-4 max-w-7xl mb-20">
        <div className="bg-white rounded-3xl shadow-xl shadow-accent/5 border border-border p-6 md:p-8 flex flex-col md:flex-row items-center justify-between gap-6">
          
          <div className="flex items-center gap-4 flex-1 justify-center md:justify-start">
            <div className="w-12 h-12 rounded-2xl bg-accent-light text-accent flex items-center justify-center font-bold text-xl shrink-0">Ar</div>
            <div>
              <p className="font-bold text-content">Dès 7 000 Ar</p>
              <p className="text-sm text-content-secondary">Des prix accessibles</p>
            </div>
          </div>
          
          <div className="hidden md:block w-px h-12 bg-border" />
          
          <div className="flex items-center gap-4 flex-1 justify-center">
            <div className="w-12 h-12 rounded-2xl bg-accent-light text-accent flex items-center justify-center shrink-0"><MapPin className="w-6 h-6" /></div>
            <div>
              <p className="font-bold text-content">Fait à Madagascar</p>
              <p className="text-sm text-content-secondary">Le talent local en avant</p>
            </div>
          </div>
          
          <div className="hidden md:block w-px h-12 bg-border" />
          
          <div className="flex items-center gap-4 flex-1 justify-center md:justify-end">
            <div className="w-12 h-12 rounded-2xl bg-accent-light text-accent flex items-center justify-center shrink-0"><Check className="w-6 h-6" /></div>
            <div>
              <p className="font-bold text-content">Licence claire</p>
              <p className="text-sm text-content-secondary">Tu sais ce que tu achètes</p>
            </div>
          </div>

        </div>
      </section>

      {/* AFFICHAGE DES STATS */}
      {stats.instrumentals > MIN_BEATS_FOR_STATS && (
        <section className="container mx-auto px-4 max-w-3xl mb-12 text-center">
          <div className="grid grid-cols-3 gap-4">
            <div>
              <p className="text-4xl font-bold text-content">{stats.instrumentals}</p>
              <p className="text-sm text-content-secondary">Instrumentales</p>
            </div>
            <div className="border-x border-border">
              <p className="text-4xl font-bold text-content">{stats.producers}</p>
              <p className="text-sm text-content-secondary">Producteurs</p>
            </div>
            <div>
              <p className="text-4xl font-bold text-content">{stats.downloads}</p>
              <p className="text-sm text-content-secondary">Téléchargements</p>
            </div>
          </div>
        </section>
      )}

      {/* ================= TENDANCES ================= */}
      {trending.length > 0 && (
        <section className="container mx-auto px-4 py-12 max-w-7xl">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase mb-2 block">La sélection Instrunaka</span>
              <h2 className="text-3xl md:text-5xl font-light tracking-tight mb-2 text-content">Tendances de la semaine</h2>
              <p className="text-content-secondary">Les beats qui font vibrer la communauté en ce moment.</p>
            </div>
            <Link href="/catalogue" className="text-sm font-semibold text-accent hover:underline flex items-center gap-1">
              Tout explorer <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {trending.map((inst) => (
              <InstrumentalCard
                key={inst.id}
                id={inst.id}
                title={inst.title}
                producerName={inst.producer?.display_name}
                coverPath={inst.cover_path}
                mood={inst.mood?.label}
                genre={inst.genre?.label}
                bpm={inst.bpm}
                musicalKey={inst.musical_key}
                price={inst.non_exclusive_price}
                exclusivePrice={inst.exclusive_price}
              />
            ))}
          </div>
        </section>
      )}

      {/* ================= DERNIERS AJOUTS ================= */}
      {recent.length > 0 && (
        <section className="container mx-auto px-4 py-12 max-w-7xl">
          <div className="flex items-end justify-between mb-8">
            <div>
              <span className="text-accent font-semibold text-sm tracking-wider uppercase mb-2 block">Tout juste sortis du studio</span>
              <h2 className="text-3xl md:text-5xl font-light tracking-tight mb-2 text-content">Derniers ajouts</h2>
              <p className="text-content-secondary">Découvre les dernières pépites déposées par nos producteurs.</p>
            </div>
            <Link href="/catalogue" className="text-sm font-semibold text-accent hover:underline flex items-center gap-1">
              Voir tout <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="flex flex-col gap-3">
            {recent.map((inst) => (
              <InstrumentalRow
                key={inst.id}
                id={inst.id}
                title={inst.title}
                producerName={inst.producer?.display_name}
                coverPath={inst.cover_path}
                mood={inst.mood?.label}
                genre={inst.genre?.label}
                bpm={inst.bpm}
                musicalKey={inst.musical_key}
                durationSeconds={inst.duration_seconds}
                price={inst.non_exclusive_price}
              />
            ))}
          </div>
        </section>
      )}

      {/* ================= BLOC PRODUCTEUR ================= */}
      <section className="container mx-auto px-4 py-16 max-w-7xl">
        <div className="bg-gradient-to-br from-accent-light to-[#E0D8FD] rounded-[40px] p-8 md:p-16 flex flex-col md:flex-row items-center justify-between gap-12 overflow-hidden relative">
          
          <div className="flex-1 text-center md:text-left relative z-10">
            <span className="text-accent font-semibold text-sm tracking-wider uppercase mb-4 block">
              Ta musique mérite d&apos;être entendue
            </span>
            <h2 className="text-4xl md:text-5xl font-light tracking-tight text-content mb-6 leading-tight">
              Tu produis des beats ?
            </h2>
            <p className="text-content-secondary mb-8 max-w-md mx-auto md:mx-0 text-lg">
              Rejoins les producteurs malgaches qui partagent leur son, développent leur audience et vivent de leur passion.
            </p>
            <Link 
              href="/inscription"
              className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-accent text-white font-semibold hover:bg-accent-hover transition-all shadow-lg shadow-accent/30 hover:-translate-y-1"
            >
              Devenir producteur <ArrowRight className="w-5 h-5" />
            </Link>
          </div>

          <div className="flex-1 relative w-full flex justify-center items-center h-[300px] md:h-[400px]">
            <div className="absolute inset-0 flex items-center justify-center gap-2 opacity-30 px-10">
              {[...Array(25)].map((_, i) => (
                <div 
                  key={i} 
                  className="w-2.5 bg-accent rounded-full eq-bar" 
                  style={{ animationDelay: `${i * 0.1}s`, height: `${20 + (i * 13) % 60}%` }} 
                />
              ))}
            </div>

            <div className="relative w-64 h-64 md:w-80 md:h-80 rounded-full bg-dark border-8 border-[#1A153A] shadow-2xl flex items-center justify-center animate-spin-slow">
              <div className="absolute inset-2 rounded-full border border-white/10" />
              <div className="absolute inset-6 rounded-full border border-white/10" />
              <div className="absolute inset-10 rounded-full border border-white/10" />
              <div className="w-24 h-24 md:w-32 md:h-32 rounded-full bg-accent flex flex-col items-center justify-center">
                <span className="text-[10px] font-bold text-white tracking-widest uppercase">Instru</span>
                <span className="text-[10px] font-bold text-white tracking-widest uppercase">naka</span>
              </div>
            </div>
          </div>
        </div>
      </section>

    </div>
  );
}