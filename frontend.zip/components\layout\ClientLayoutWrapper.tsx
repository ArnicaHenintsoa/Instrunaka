"use client";

import { usePathname } from "next/navigation";
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import MobileNav from "@/components/layout/MobileNav";
import PlayerBar from "@/components/player/PlayerBar";
import HeaderWrapper from "@/components/layout/HeaderWrapper";

export default function ClientLayoutWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const isAdmin = pathname?.startsWith("/admin");

  if (isAdmin) {
    return (
      <main className="flex-1">
        {children}
        <PlayerBar />
      </main>
    );
  }

  return (
    <>
      <HeaderWrapper>
        <Header />
      </HeaderWrapper>
      <main className="flex-1 pb-32 lg:pb-24">
        {children}
      </main>
      <Footer />
      <PlayerBar />
      <MobileNav />
    </>
  );
}