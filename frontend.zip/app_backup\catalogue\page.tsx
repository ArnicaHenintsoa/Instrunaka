"use client";

import { useState, useEffect, useCallback, Suspense } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { api } from "@/lib/api";
import InstrumentalCard from "@/components/instrumental/InstrumentalCard";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";

type Instrumental = {
  id: number;
  title: string;
  cover_path: string | null;
  bpm: number | null;
  non_exclusive_price: number;
  producer?: { display_name: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
};

type FilterItem = {
  id: number;
  name: string;
  label: string;
};

type Meta = {
  current_page: number;
  per_page: number;
  total: number;
  last_page: number;
};

function CatalogueContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [instrumentals, setInstrumentals] = useState<Instrumental[]>([]);
  const [moods, setMoods] = useState<FilterItem[]>([]);
  const [rhythms, setRhythms] = useState<FilterItem[]>([]);
  const [genres, setGenres] = useState<FilterItem[]>([]);
  const [meta, setMeta] = useState<Meta | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const currentMood = searchParams.get("mood_id") || "";
  const currentRhythm = searchParams.get("rhythm_id") || "";
  const currentGenre = searchParams.get("genre_id") || "";
  const currentSearch = searchParams.get("search") || "";
  const currentPage = Number.parseInt(searchParams.get("page") || "1", 10);

  // Chargement des classifications au montage
  useEffect(() => {
    async function loadClassifications() {
      try {
        const [moodsRes, rhythmsRes, genresRes] = await Promise.all([
          api.get("/moods"),
          api.get("/rhythms"),
          api.get("/genres"),
        ]);
        setMoods(moodsRes?.data ?? []);
        setRhythms(rhythmsRes?.data ?? []);
        setGenres(genresRes?.data ?? []);
      } catch (e) {
        console.error("Erreur chargement classifications", e);
      }
    }
    loadClassifications();
  }, []);

  // Chargement des instrumentales à chaque changement de filtre
  const loadInstrumentals = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const params = new URLSearchParams();
      if (currentMood) params.append("mood_id", currentMood);
      if (currentRhythm) params.append("rhythm_id", currentRhythm);
      if (currentGenre) params.append("genre_id", currentGenre);
      if (currentSearch) params.append("search", currentSearch);
      params.append("page", currentPage.toString());

      const res = await api.get(`/instrumentals?${params.toString()}`);
      setInstrumentals(res?.data ?? []);
      setMeta(res?.meta ?? null);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Erreur de chargement");
    } finally {
      setLoading(false);
    }
  }, [currentMood, currentRhythm, currentGenre, currentSearch, currentPage]);

  useEffect(() => {
    loadInstrumentals();
  }, [loadInstrumentals]);

  const updateFilters = (updates: Record<string, string | null>) => {
    const params = new URLSearchParams(searchParams.toString());

    Object.entries(updates).forEach(([key, value]) => {
      if (value) {
        params.set(key, value);
      } else {
        params.delete(key);
      }
    });

    if (!("page" in updates)) {
      params.delete("page");
    }

    router.push(`/catalogue?${params.toString()}`);
  };

  const resetFilters = () => {
    router.push("/catalogue");
  };

  const hasActiveFilters = currentMood || currentRhythm || currentGenre || currentSearch;

  // Message du compteur (extrait du JSX pour éviter les ternaires imbriqués)
  let countMessage = "Chargement...";
  if (meta) {
    const plural = meta.total > 1 ? "s" : "";
    countMessage = `${meta.total} instrumentale${plural} trouvée${plural}`;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Catalogue</h1>
        <p className="text-content-secondary">
          {countMessage}
          {hasActiveFilters && (
            <button
              onClick={resetFilters}
              className="ml-3 text-accent hover:underline text-sm"
            >
              Réinitialiser les filtres
            </button>
          )}
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* SIDEBAR FILTRES */}
        <aside className="lg:w-64 shrink-0">
          <Card padding="lg">
            <h2 className="font-semibold mb-4">Filtres</h2>

            <div className="mb-6">
              <h3 className="text-sm font-medium mb-2">Humeur</h3>
              <div className="flex flex-wrap gap-2">
                {moods.map((mood) => {
                  const isActive = currentMood === mood.id.toString();
                  return (
                    <button
                      key={mood.id}
                      onClick={() =>
                        updateFilters({
                          mood_id: isActive ? null : mood.id.toString(),
                        })
                      }
                      className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                        isActive
                          ? "bg-accent text-white"
                          : "bg-background-secondary text-content hover:bg-accent-light"
                      }`}
                    >
                      {mood.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mb-6">
              <h3 className="text-sm font-medium mb-2">Rythme</h3>
              <div className="flex flex-wrap gap-2">
                {rhythms.map((rhythm) => {
                  const isActive = currentRhythm === rhythm.id.toString();
                  return (
                    <button
                      key={rhythm.id}
                      onClick={() =>
                        updateFilters({
                          rhythm_id: isActive ? null : rhythm.id.toString(),
                        })
                      }
                      className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                        isActive
                          ? "bg-accent text-white"
                          : "bg-background-secondary text-content hover:bg-accent-light"
                      }`}
                    >
                      {rhythm.label}
                    </button>
                  );
                })}
              </div>
            </div>

            <div>
              <h3 className="text-sm font-medium mb-2">Genre</h3>
              <div className="flex flex-wrap gap-2">
                {genres.map((genre) => {
                  const isActive = currentGenre === genre.id.toString();
                  return (
                    <button
                      key={genre.id}
                      onClick={() =>
                        updateFilters({
                          genre_id: isActive ? null : genre.id.toString(),
                        })
                      }
                      className={`px-3 py-1 rounded-full text-xs font-medium transition-colors ${
                        isActive
                          ? "bg-accent text-white"
                          : "bg-background-secondary text-content hover:bg-accent-light"
                      }`}
                    >
                      {genre.label}
                    </button>
                  );
                })}
              </div>
            </div>
          </Card>
        </aside>

        {/* GRILLE */}
        <div className="flex-1">
          <div className="mb-6">
            <input
              type="text"
              placeholder="Rechercher par titre..."
              defaultValue={currentSearch}
              onKeyDown={(e) => {
                if (e.key === "Enter") {
                  updateFilters({
                    search: (e.target as HTMLInputElement).value || null,
                  });
                }
              }}
              className="w-full px-4 py-2 rounded-xl bg-white border border-border focus:border-accent text-sm"
            />
            <p className="text-xs text-content-secondary mt-1">
              Appuyez sur Entrée pour rechercher
            </p>
          </div>

          {loading && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {Array.from({ length: 6 }, (_, i) => (
                <div
                  key={`skeleton-${i}`}
                  className="aspect-square bg-white border border-border rounded-2xl animate-pulse"
                />
              ))}
            </div>
          )}

          {!loading && error && (
            <Card padding="lg">
              <p className="text-danger">{error}</p>
            </Card>
          )}

          {!loading && !error && instrumentals.length === 0 && (
            <Card padding="lg" className="text-center">
              <p className="text-content-secondary mb-2">
                Aucune instrumentale ne correspond à votre recherche.
              </p>
              {hasActiveFilters && (
                <Button variant="secondary" onClick={resetFilters}>
                  Réinitialiser les filtres
                </Button>
              )}
            </Card>
          )}

          {!loading && !error && instrumentals.length > 0 && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                {instrumentals.map((inst) => (
                  <InstrumentalCard
                    key={inst.id}
                    id={inst.id}
                    title={inst.title}
                    producerName={inst.producer?.display_name}
                    coverPath={inst.cover_path}
                    mood={inst.mood?.label}
                    rhythm={inst.rhythm?.label}
                    bpm={inst.bpm}
                    price={inst.non_exclusive_price}
                  />
                ))}
              </div>

              {meta && meta.last_page > 1 && (
                <div className="flex items-center justify-center gap-2 mt-8">
                  <Button
                    variant="secondary"
                    size="sm"
                    disabled={meta.current_page === 1}
                    onClick={() =>
                      updateFilters({ page: (meta.current_page - 1).toString() })
                    }
                  >
                    ← Précédent
                  </Button>

                  <span className="text-sm text-content-secondary px-4">
                    Page {meta.current_page} sur {meta.last_page}
                  </span>

                  <Button
                    variant="secondary"
                    size="sm"
                    disabled={meta.current_page === meta.last_page}
                    onClick={() =>
                      updateFilters({ page: (meta.current_page + 1).toString() })
                    }
                  >
                    Suivant →
                  </Button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}

export default function CataloguePage() {
  return (
    <Suspense
      fallback={
        <div className="container mx-auto px-4 py-8">
          <p className="text-content-secondary">Chargement du catalogue...</p>
        </div>
      }
    >
      <CatalogueContent />
    </Suspense>
  );
}