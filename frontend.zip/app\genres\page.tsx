import Link from "next/link";
import { api } from "@/lib/api";
import PageContainer from "@/components/layout/PageContainer";
import PageHeader from "@/components/layout/PageHeader";
import { Music, ArrowRight, Disc3 } from "lucide-react";

export default async function GenresPage() {
  let genres: { id: number; label: string }[] = [];

  try {
    const res = await api.get("/genres");
    genres = res?.data ?? [];
  } catch (e) {
    console.error(e);
  }

  // Dégradé déterministe basé sur l'id
  const getGradient = (id: number) => {
    const hue = (id * 137) % 360;
    return `linear-gradient(135deg, hsl(${hue}, 70%, 75%), hsl(${(hue + 40) % 360}, 70%, 55%))`;
  };

  return (
    <PageContainer>
      <PageHeader 
        label="EXPLORER" 
        title="Les genres" 
        subtitle="Trouve le style qui correspond à ton projet."
      />

      {genres.length === 0 ? (
        <div className="bg-white border border-border rounded-3xl p-12 text-center">
          <div className="w-16 h-16 bg-accent-light text-accent rounded-full flex items-center justify-center mx-auto mb-4">
            <Music className="w-8 h-8" />
          </div>
          <p className="text-content-secondary">Aucun genre disponible pour le moment.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-5 pb-16">
          {genres.map((genre) => (
            <Link
              key={genre.id}
              href={`/catalogue?genre_id=${genre.id}`}
              className="group relative h-48 rounded-3xl overflow-hidden shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300"
              style={{ background: getGradient(genre.id) }}
            >
              {/* Overlay sombre pour lisibilité */}
              <div className="absolute inset-0 bg-black/20 group-hover:bg-black/10 transition-colors" />
              
              {/* Icône décorative */}
              <div className="absolute top-4 right-4 opacity-30 group-hover:opacity-50 transition-opacity">
                <Disc3 className="w-16 h-16 text-white" />
              </div>

              {/* Contenu */}
              <div className="absolute bottom-0 left-0 right-0 p-5">
                <h2 className="text-xl font-bold text-white mb-1 drop-shadow-md">
                  {genre.label}
                </h2>
                <span className="text-xs font-semibold text-white/90 flex items-center gap-1 group-hover:gap-2 transition-all">
                  Découvrir <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </PageContainer>
  );
}