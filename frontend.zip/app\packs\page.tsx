"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";

type Pack = {
  id: number;
  name: string;
  description: string | null;
  price: number;
  cover_path: string | null;
  instrumentals: {
    id: number;
    title: string;
    cover_path: string | null;
    non_exclusive_price: number;
    producer?: { display_name: string } | null;
  }[];
};

export default function PacksPage() {
  const [packs, setPacks] = useState<Pack[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await api.get("/packs");
        setPacks(res?.data ?? []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    void load();
  }, []);

  if (loading) return <div className="container mx-auto px-4 py-16 text-center">Chargement...</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 text-center">
        <h1 className="text-4xl font-bold mb-3">📦 Nos Packs</h1>
        <p className="text-content-secondary text-lg">
          Économisez en achetant plusieurs instrumentales groupées.
        </p>
      </div>

      {packs.length === 0 ? (
        <Card padding="lg" className="text-center py-16">
          <span className="text-5xl block mb-4">📦</span>
          <p className="text-content-secondary">Aucun pack disponible pour le moment.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {packs.map((pack) => {
            const originalPrice = pack.instrumentals.reduce(
              (acc, i) => acc + i.non_exclusive_price,
              0
            );
            const savings = originalPrice - pack.price;
            return (
              <Card key={pack.id} padding="lg">
                <div className="flex items-start justify-between mb-3">
                  <h2 className="text-2xl font-bold">{pack.name}</h2>
                  {savings > 0 && (
                    <Badge variant="success">
                      -{Math.round((savings / originalPrice) * 100)}%
                    </Badge>
                  )}
                </div>
                {pack.description && (
                  <p className="text-content-secondary text-sm mb-4">{pack.description}</p>
                )}

                <div className="space-y-2 mb-4">
                  {pack.instrumentals.map((inst) => (
                    <div key={inst.id} className="flex items-center gap-3 p-2 bg-background-secondary rounded-lg">
                      <div className="w-10 h-10 bg-accent-light rounded-lg flex items-center justify-center text-accent">
                        ♪
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium">{inst.title}</p>
                        <p className="text-xs text-content-secondary">{inst.producer?.display_name}</p>
                      </div>
                      <span className="text-xs text-content-secondary line-through">
                        {inst.non_exclusive_price} Ar
                      </span>
                    </div>
                  ))}
                </div>

                <div className="pt-4 border-t border-border">
                  {savings > 0 && (
                    <p className="text-xs text-content-secondary mb-1">
                      Prix cumulé : <span className="line-through">{originalPrice.toLocaleString("fr-FR")} Ar</span>
                    </p>
                  )}
                  <div className="flex items-center justify-between">
                    <span className="text-2xl font-bold text-accent">
                      {pack.price.toLocaleString("fr-FR")} Ar
                    </span>
                    <Link href={`/packs/${pack.id}`}>
                      <button className="px-4 py-2 bg-accent text-white rounded-xl text-sm font-medium hover:bg-accent-hover transition-colors">
                        Voir le pack
                      </button>
                    </Link>
                  </div>
                  {savings > 0 && (
                    <p className="text-xs text-success mt-1">
                      Vous économisez {savings.toLocaleString("fr-FR")} Ar !
                    </p>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}