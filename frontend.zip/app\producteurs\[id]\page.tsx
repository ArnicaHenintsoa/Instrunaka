"use client";

import { use, useEffect, useState } from "react";
import Link from "next/link";
import { api } from "@/lib/api";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import Button from "@/components/ui/Button";
import InstrumentalCard from "@/components/instrumental/InstrumentalCard";
import FollowButton from "@/components/producer/FollowButton";

type Instrumental = {
  id: number;
  title: string;
  cover_path: string | null;
  bpm: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
};

type Producer = {
  id: number;
  display_name: string;
  bio: string | null;
  verified: boolean;
  followers_count: number;
  instrumentals: Instrumental[];
};

type PageProps = Readonly<{ params: Promise<{ id: string }> }>;

export default function ProducerPage({ params }: PageProps) {
  const { id } = use(params);
  const [producer, setProducer] = useState<Producer | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const res = await api.get(`/producers/${id}`);
        setProducer(res?.data);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    void load();
  }, [id]);

  if (loading) return <div className="container mx-auto px-4 py-16 text-center">Chargement...</div>;
  if (!producer) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <Card padding="lg" className="max-w-md mx-auto">
          <p className="text-danger mb-4">Producteur introuvable.</p>
          <Link href="/catalogue"><Button variant="secondary">← Retour au catalogue</Button></Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* En-tête producteur */}
      <Card padding="lg" className="mb-8">
        <div className="flex items-center gap-6 flex-wrap">
          <div className="w-20 h-20 bg-accent text-white rounded-full flex items-center justify-center text-3xl font-bold">
            {producer.display_name.charAt(0).toUpperCase()}
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-1">
              <h1 className="text-3xl font-bold">{producer.display_name}</h1>
              {producer.verified && <Badge variant="accent">✓ Vérifié</Badge>}
            </div>
            <p className="text-content-secondary text-sm">
              {producer.followers_count} follower{producer.followers_count > 1 ? "s" : ""} ·{" "}
              {producer.instrumentals.length} instrumentale{producer.instrumentals.length > 1 ? "s" : ""}
            </p>
            {producer.bio && <p className="text-content-secondary mt-3">{producer.bio}</p>}
          </div>
          <FollowButton producerId={producer.id} size="md" />
        </div>
      </Card>

      {/* Instrumentales */}
      <h2 className="text-2xl font-bold mb-4">Ses créations</h2>
      {producer.instrumentals.length === 0 ? (
        <Card padding="lg" className="text-center py-16">
          <p className="text-content-secondary">Ce producteur n&apos;a pas encore publié d&apos;instrumentale.</p>
        </Card>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {producer.instrumentals.map((inst) => (
            <InstrumentalCard
              key={inst.id}
              id={inst.id}
              title={inst.title}
              producerName={producer.display_name}
              coverPath={inst.cover_path}
              mood={inst.mood?.label}
              rhythm={inst.rhythm?.label}
              bpm={inst.bpm}
              price={inst.non_exclusive_price}
              exclusivePrice={inst.exclusive_price}
            />
          ))}
        </div>
      )}
    </div>
  );
}