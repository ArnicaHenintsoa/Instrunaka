"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";
import ConfirmModal from "@/components/ui/ConfirmModal";

type User = {
  id: number;
  name: string;
  email: string;
  status: string;
  is_producer: boolean;
  is_admin: boolean;
  role: string;
  created_at: string;
};

export default function ProfilPage() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [confirmLogout, setConfirmLogout] = useState(false);

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/profil");
      return;
    }

    async function loadUser() {
      try {
        const res = await api.get("/auth/me");
        setUser(res?.user);
      } catch {
        auth.removeToken();
        router.push("/connexion");
      } finally {
        setLoading(false);
      }
    }
    void loadUser();
  }, [router]);

   const handleLogout = async () => {
    try {
      // Appel API pour fermer la session côté backend
      await api.post("/auth/logout");
    } catch (e) {
      console.error("Erreur logout:", e);
    } finally {
      auth.removeToken();
      window.location.href = "/?logout=1";
    }
  };

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <p className="text-content-secondary">Chargement...</p>
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <h1 className="text-3xl font-bold mb-6">Mon profil</h1>

      <Card padding="lg" className="mb-6">
        <div className="flex items-start justify-between mb-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-accent text-white rounded-full flex items-center justify-center text-2xl font-bold">
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h2 className="text-xl font-semibold">{user.name}</h2>
              <p className="text-sm text-content-secondary">{user.email}</p>
            </div>
          </div>
        </div>

        <dl className="grid grid-cols-2 gap-4 text-sm pt-6 border-t border-border">
          <div>
            <dt className="text-content-secondary">Rôle</dt>
            <dd className="font-medium capitalize">{user.role}</dd>
          </div>
          <div>
            <dt className="text-content-secondary">Statut</dt>
            <dd>
              <Badge variant={user.status === "active" ? "success" : "danger"}>
                {user.status === "active" ? "Actif" : user.status}
              </Badge>
            </dd>
          </div>
          <div>
            <dt className="text-content-secondary">Producteur</dt>
            <dd>
              {user.is_producer ? (
                <Badge variant="accent">Oui</Badge>
              ) : (
                <span className="text-content-secondary">Non</span>
              )}
            </dd>
          </div>
          <div>
            <dt className="text-content-secondary">Membre depuis</dt>
            <dd className="font-medium">
              {new Date(user.created_at).toLocaleDateString("fr-FR", {
                day: "2-digit",
                month: "long",
                year: "numeric",
              })}
            </dd>
          </div>
        </dl>
      </Card>

      <div className="flex flex-wrap gap-3">
        {!user.is_producer && (
          <Link href="/profil/devenir-producteur">
            <Button variant="primary">🎵 Devenir Producteur</Button>
          </Link>
        )}
        {user.is_producer && (
          <>
            <Link href="/profil/soumettre">
              <Button variant="primary">🎵 Soumettre une instrumentale</Button>
            </Link>
            <Link href="/profil/mes-soumissions">
              <Button variant="secondary">📋 Mes soumissions</Button>
            </Link>
          </>
        )}
        <Link href="/profil/producteurs-suivis">
          <Button variant="secondary">👥 Producteurs suivis</Button>
        </Link>
        <Link href="/profil/playlists">
          <Button variant="secondary">🎵 Mes playlists</Button>
        </Link>
        <Button
          variant="secondary"
          onClick={() => router.push("/mes-achats")}
        >
          Mes achats
        </Button>
        <Button variant="ghost" onClick={() => setConfirmLogout(true)}>
          Déconnexion
        </Button>
      </div>

      <ConfirmModal
        isOpen={confirmLogout}
        onClose={() => setConfirmLogout(false)}
        onConfirm={handleLogout}
        title="Se déconnecter ?"
        message="Vous devrez vous reconnecter pour accéder à vos achats et à votre profil."
        confirmLabel="Se déconnecter"
        cancelLabel="Annuler"
        variant="danger"
      />
    </div>
  );
}