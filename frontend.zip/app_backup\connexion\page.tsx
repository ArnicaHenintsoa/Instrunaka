"use client";

import { useState, Suspense } from "react";
import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Input from "@/components/ui/Input";
import PasswordInput from "@/components/ui/PasswordInput";
import Card from "@/components/ui/Card";
import Toast from "@/components/ui/Toast";
import { PLATFORM } from "@/lib/config";

function ConnexionContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  // Sécurité : n'accepter qu'un chemin interne
  const rawRedirect = searchParams.get("redirect") || "/";
  const redirectTo =
    rawRedirect.startsWith("/") &&
    !rawRedirect.startsWith("//") &&
    !rawRedirect.startsWith("/\\")
      ? rawRedirect
      : "/";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const handleSubmit = async (e: React.SyntheticEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    try {
      const res = await api.post("/auth/login", { email, password });

      if (!res || !res.token) {
        throw new Error("Erreur serveur : Token manquant.");
      }

      auth.setToken(res.token);
      setShowSuccess(true);

      setTimeout(() => {
        router.push(redirectTo);
        router.refresh();
      }, 800);
    } catch (err: unknown) {
      if (err instanceof Error) {
        setError(err.message);
      } else {
        setError("Identifiants incorrects.");
      }
      setLoading(false);
    }
  };

  // URL Google dynamique
  const googleRedirectUrl = `${
    process.env.NEXT_PUBLIC_API_URL || "http://localhost:8000/api"
  }/auth/google/redirect`;

  return (
    <div className="container mx-auto px-4 py-16 flex justify-center">
      {showSuccess && (
        <Toast
          message="Connexion réussie. Bienvenue !"
          variant="success"
          onClose={() => setShowSuccess(false)}
        />
      )}

      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">Connexion</h1>
          <p className="text-content-secondary">
            Accédez à votre compte {PLATFORM.name}
          </p>
        </div>

        <Card padding="lg">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="bg-danger/10 border border-danger/20 text-danger text-sm rounded-xl p-3">
                {error}
              </div>
            )}

            <Input
              label="Email"
              type="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="vous@exemple.com"
              required
              autoComplete="email"
            />

            <PasswordInput
              label="Mot de passe"
              name="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              autoComplete="current-password"
            />

            <div className="flex justify-end">
              <Link
                href="/mot-de-passe-oublie"
                className="text-sm text-accent hover:underline font-medium"
              >
                Mot de passe oublié ?
              </Link>
            </div>

            <Button
              type="submit"
              loading={loading}
              className="w-full"
              size="lg"
            >
              Se connecter
            </Button>

            {/* Continuer avec Google */}
            <div className="mt-6">
              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="bg-background px-3 text-content-secondary">
                    ou continuer avec
                  </span>
                </div>
              </div>

              <a
                href={googleRedirectUrl}
                className="mt-4 flex items-center justify-center gap-3 w-full px-5 py-3 bg-white border border-border rounded-xl font-medium text-sm hover:bg-background-secondary transition-colors"
              >
                <svg width="18" height="18" viewBox="0 0 24 24">
                  <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continuer avec Google
              </a>
            </div>
          </form>

          <div className="mt-6 pt-6 border-t border-border text-center text-sm">
            <span className="text-content-secondary">
              Pas encore de compte ?{" "}
            </span>
            <Link
              href="/inscription"
              className="text-accent font-medium hover:underline"
            >
              Créer un compte
            </Link>
          </div>
        </Card>

        <p className="text-xs text-center text-content-secondary mt-6">
          La connexion est obligatoire pour tout achat ou téléchargement.
          La consultation reste libre.
        </p>
      </div>
    </div>
  );
}

export default function ConnexionPage() {
  return (
    <Suspense
      fallback={
        <div className="container mx-auto px-4 py-16 text-center">
          <p className="text-content-secondary">Chargement...</p>
        </div>
      }
    >
      <ConnexionContent />
    </Suspense>
  );
}