import Link from "next/link";
import Card from "@/components/ui/Card";
import { PLATFORM } from "@/lib/config";

export const metadata = {
  title: `Conditions & Remboursement — ${PLATFORM.fullName}`,
  description: "Conditions d&apos;achat, de téléchargement et politique de remboursement.",
};

export default function ConditionsPage() {
  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl">
      <h1 className="text-4xl font-bold mb-3">Conditions & Politique de remboursement</h1>
      <p className="text-content-secondary mb-8">
        Dernière mise à jour : {new Date().toLocaleDateString("fr-FR", { day: "2-digit", month: "long", year: "numeric" })}
      </p>

      <Card padding="lg" className="mb-6">
        <h2 className="text-2xl font-bold mb-3">1. Objet</h2>
        <p className="text-content-secondary leading-relaxed">
          La plateforme <strong>{PLATFORM.fullName}</strong> permet aux utilisateurs de découvrir,
          écouter et acheter des instrumentales musicales. En effectuant un achat, l&apos;utilisateur
          accepte sans réserve les présentes conditions.
        </p>
      </Card>

      <Card padding="lg" className="mb-6">
        <h2 className="text-2xl font-bold mb-3">2. Types de licences</h2>
        <p className="text-content-secondary leading-relaxed mb-3">
          Deux types de licences sont proposés :
        </p>
        <ul className="list-disc pl-6 text-content-secondary space-y-2">
          <li>
            <strong>Licence non exclusive :</strong> l&apos;acheteur reçoit les fichiers MP3 et WAV.
            L&apos;instrumentale reste disponible à la vente pour d&apos;autres utilisateurs.
          </li>
          <li>
            <strong>Licence exclusive :</strong> l&apos;acheteur devient l&apos;unique propriétaire de
            l&apos;instrumentale. Celle-ci est retirée du catalogue après validation du paiement.
          </li>
        </ul>
      </Card>

      <Card padding="lg" className="mb-6">
        <h2 className="text-2xl font-bold mb-3">3. Modalités de paiement</h2>
        <p className="text-content-secondary leading-relaxed">
          Le paiement s&apos;effectue par Mobile Banking. Un code de référence unique est généré
          pour chaque commande. La commande est validée manuellement par notre équipe après
          vérification du transfert. Les fichiers sont ensuite accessibles dans l&apos;espace
          <strong> Mes achats</strong> du client.
        </p>
      </Card>

      <Card padding="lg" className="mb-6">
        <h2 className="text-2xl font-bold mb-3">4. Politique de remboursement</h2>
        <p className="text-content-secondary leading-relaxed mb-3">
          En raison de la nature numérique des produits vendus :
        </p>
        <ul className="list-disc pl-6 text-content-secondary space-y-2">
          <li>
            <strong>Aucun remboursement</strong> n&apos;est possible après le téléchargement des
            fichiers (MP3 et WAV).
          </li>
          <li>
            En cas de commande <strong>non validée</strong> par l&apos;équipe (paiement non reçu,
            référence incorrecte), l&apos;utilisateur peut demander l&apos;annulation. Aucun montant
            n&apos;ayant été débité par la plateforme, aucun remboursement n&apos;est nécessaire.
          </li>
          <li>
            En cas de problème technique majeur (fichier corrompu, inaccessible), une assistance
            est fournie par notre équipe à l&apos;adresse :{" "}
            <a href={`mailto:${PLATFORM.contact.email}`} className="text-accent hover:underline">
              {PLATFORM.contact.email}
            </a>
            .
          </li>
        </ul>
      </Card>

      <Card padding="lg" className="mb-6">
        <h2 className="text-2xl font-bold mb-3">5. Propriété intellectuelle</h2>
        <p className="text-content-secondary leading-relaxed">
          Les instrumentales mises en vente restent la propriété intellectuelle de leurs
          producteurs. L&apos;acheteur obtient une licence d&apos;utilisation selon les termes de la
          licence choisie. Toute revente, redistribution ou utilisation non autorisée est
          strictement interdite.
        </p>
      </Card>

      <Card padding="lg" className="mb-6">
        <h2 className="text-2xl font-bold mb-3">6. Données personnelles</h2>
        <p className="text-content-secondary leading-relaxed">
          Les données collectées (nom, email, historique d&apos;achats) sont utilisées uniquement
          dans le cadre du fonctionnement de la plateforme. Elles ne sont jamais partagées
          avec des tiers sans consentement.
        </p>
      </Card>

      <Card padding="lg">
        <h2 className="text-2xl font-bold mb-3">7. Contact</h2>
        <p className="text-content-secondary leading-relaxed">
          Pour toute question relative aux conditions ou au remboursement :
        </p>
        <ul className="mt-3 text-content-secondary space-y-1">
          <li>
            📧{" "}
            <a href={`mailto:${PLATFORM.contact.email}`} className="text-accent hover:underline">
              {PLATFORM.contact.email}
            </a>
          </li>
          <li>📞 {PLATFORM.contact.phone}</li>
          <li>📍 {PLATFORM.contact.address}</li>
        </ul>
      </Card>

      <div className="mt-8 text-center">
        <Link href="/" className="text-accent hover:underline text-sm">
          ← Retour à l&apos;accueil
        </Link>
      </div>
    </div>
  );
}