import Link from "next/link";
import { api } from "@/lib/api";
import InstrumentalCard from "@/components/instrumental/InstrumentalCard";
import Button from "@/components/ui/Button";

type Instrumental = {
  id: number;
  title: string;
  cover_path: string | null;
  bpm: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  producer?: { display_name: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
};

type Mood = {
  id: number;
  name: string;
  label: string;
};

export default async function HomePage() {
  let instrumentals: Instrumental[] = [];
  let moods: Mood[] = [];
  let error: string | null = null;

  try {
    const instrumentsRes = await api.get("/instrumentals?sort=recent");
    instrumentals = (instrumentsRes?.data ?? []).slice(0, 8);

    const moodsRes = await api.get("/moods");
    moods = moodsRes?.data ?? [];
  } catch (e: unknown) {
    error = e instanceof Error ? e.message : "Erreur de chargement";
  }

  return (
    <div>
      {/* ==================== HERO ==================== */}
      <section className="relative overflow-hidden border-b border-border bg-gradient-to-br from-accent-light via-accent-lighter to-background">
        <div className="absolute top-0 right-0 w-96 h-96 bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-accent/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/3 pointer-events-none" />

        <div className="container mx-auto px-4 py-20 md:py-28 relative">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-white/80 backdrop-blur-sm text-accent rounded-full text-xs font-semibold mb-6 shadow-sm">
              <span className="w-1.5 h-1.5 bg-accent rounded-full animate-pulse" />
              <span>Catalogue mis à jour chaque semaine</span>
            </div>

            <h1 className="text-5xl md:text-6xl font-bold tracking-tight mb-6 leading-[1.1]">
              <span>Découvrez des</span>{" "}
              <span className="text-accent">instrumentales</span>{" "}
              <span>de qualité</span>
            </h1>
            <p className="text-lg md:text-xl text-content-secondary mb-10 max-w-2xl leading-relaxed">
              Explorez un catalogue varié pour vos projets musicaux.
              Écoutez, choisissez, téléchargez en quelques clics.
            </p>

            <form
              action="/catalogue"
              method="get"
              className="flex flex-col sm:flex-row gap-3 mb-8 max-w-xl"
            >
              <div className="relative flex-1">
                <input
                  type="text"
                  name="search"
                  placeholder="Rechercher une instrumentale..."
                  className="w-full px-5 py-4 pl-12 rounded-2xl bg-white border-2 border-transparent focus:border-accent text-sm transition-colors shadow-card"
                />
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-content-secondary text-lg">
                  🔍
                </span>
              </div>
              <Button type="submit" size="lg" className="rounded-2xl shadow-card">
                Rechercher
              </Button>
            </form>

            <div className="flex flex-wrap gap-3">
              <Link href="/catalogue">
                <Button variant="secondary" size="lg" className="bg-white/80 backdrop-blur-sm">
                  Explorer le catalogue →
                </Button>
              </Link>
              <Link href="/inscription">
                <Button variant="ghost" size="lg">
                  Devenir producteur
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ==================== FILTRES RAPIDES ==================== */}
      {moods.length > 0 && (
        <section className="border-b border-border bg-white/60 backdrop-blur-sm">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center gap-3 flex-wrap">
              <span className="text-sm font-semibold text-content-secondary">
                Filtrer par humeur :
              </span>
              {moods.map((mood) => (
                <Link
                  key={mood.id}
                  href={`/catalogue?mood_id=${mood.id}`}
                  className="px-4 py-2 bg-white border border-border rounded-full text-sm font-medium hover:border-accent hover:text-accent hover:shadow-soft transition-all duration-200"
                >
                  {mood.label}
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ==================== GRILLE NOUVEAUTÉS ==================== */}
      <section className="container mx-auto px-4 py-16">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-2">Nouveautés</h2>
            <p className="text-content-secondary">
              Les dernières instrumentales ajoutées au catalogue
            </p>
          </div>
          <Link
            href="/catalogue"
            className="text-sm font-semibold text-accent hover:underline whitespace-nowrap hidden md:block"
          >
            Voir tout →
          </Link>
        </div>

        {error && (
          <div className="bg-danger/10 border border-danger/20 text-danger rounded-xl p-4 mb-6">
            {error}
          </div>
        )}

        {!error && instrumentals.length === 0 && (
          <div className="bg-white border border-border rounded-2xl p-16 text-center">
            <span className="text-5xl block mb-4">🎵</span>
            <p className="text-content font-medium mb-2">
              Aucune instrumentale disponible
            </p>
            <p className="text-sm text-content-secondary">
              Revenez bientôt pour découvrir de nouvelles créations.
            </p>
          </div>
        )}

        {instrumentals.length > 0 && (
          <>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
              {instrumentals.map((inst) => (
                <InstrumentalCard
                  key={inst.id}
                  id={inst.id}
                  title={inst.title}
                  producerName={inst.producer?.display_name}
                  coverPath={inst.cover_path}
                  mood={inst.mood?.label}
                  rhythm={inst.rhythm?.label}
                  bpm={inst.bpm}
                  price={inst.non_exclusive_price}
                  exclusivePrice={inst.exclusive_price}
                />
              ))}
            </div>

            <div className="flex justify-center mt-10 md:hidden">
              <Link href="/catalogue">
                <Button variant="secondary">Voir tout le catalogue →</Button>
              </Link>
            </div>
          </>
        )}
      </section>

      {/* ==================== APPEL À L'ACTION PRODUCTEUR ==================== */}
      <section className="relative overflow-hidden border-t border-border bg-gradient-to-br from-accent-light via-accent-lighter to-white">
        <div className="absolute top-1/2 right-0 w-80 h-80 bg-accent/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />

        <div className="container mx-auto px-4 py-20 text-center relative">
          <div className="max-w-2xl mx-auto">
            <span className="text-5xl block mb-6">🎹</span>
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              Vous êtes producteur ?
            </h2>
            <p className="text-content-secondary text-lg mb-8">
              Proposez vos instrumentales à un public d&apos;artistes et
              bénéficiez d&apos;une visibilité sur notre catalogue.
            </p>
            <Link href="/inscription">
              <Button size="lg" className="rounded-2xl shadow-card">
                Commencer maintenant
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}