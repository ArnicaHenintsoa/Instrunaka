"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import InstrumentalCard from "@/components/instrumental/InstrumentalCard";

type Instrumental = {
  id: number;
  title: string;
  cover_path: string | null;
  bpm: number | null;
  non_exclusive_price: number;
  exclusive_price: number;
  producer?: { display_name: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
};

export default function FavorisPage() {
  const router = useRouter();
  const [favorites, setFavorites] = useState<Instrumental[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/favoris");
      return;
    }

    async function loadFavorites() {
      try {
        const res = await api.get("/favorites");
        setFavorites(res?.data ?? []);
      } catch (e: unknown) {
        setError(e instanceof Error ? e.message : "Erreur de chargement");
      } finally {
        setLoading(false);
      }
    }
    void loadFavorites();
  }, [router]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-16">
        <p className="text-content-secondary">Chargement...</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Mes favoris</h1>
        <p className="text-content-secondary">
          Retrouvez ici toutes les instrumentales que vous avez enregistrées.
        </p>
      </div>

      {error && (
        <Card padding="lg" className="mb-6">
          <p className="text-danger">{error}</p>
        </Card>
      )}

      {favorites.length === 0 && !error && (
        <Card padding="lg" className="text-center py-16">
          <span className="text-5xl block mb-4">⭐</span>
          <p className="text-content-secondary mb-4">
            Vous n&apos;avez pas encore de favoris.
          </p>
          <Link href="/catalogue">
            <Button>Explorer le catalogue</Button>
          </Link>
        </Card>
      )}

      {favorites.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-5">
          {favorites.map((inst) => (
            <InstrumentalCard
              key={inst.id}
              id={inst.id}
              title={inst.title}
              producerName={inst.producer?.display_name}
              coverPath={inst.cover_path}
              mood={inst.mood?.label}
              rhythm={inst.rhythm?.label}
              bpm={inst.bpm}
              price={inst.non_exclusive_price}
              exclusivePrice={inst.exclusive_price}
            />
          ))}
        </div>
      )}
    </div>
  );
}