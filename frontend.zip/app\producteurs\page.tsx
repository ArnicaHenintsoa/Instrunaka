import Link from "next/link";
import { api } from "@/lib/api";
import PageContainer from "@/components/layout/PageContainer";
import PageHeader from "@/components/layout/PageHeader";
import { Mic2, ArrowRight } from "lucide-react";

type Producer = {
  id: number;
  display_name: string;
  bio: string | null;
  verified?: boolean;
  instrumentals_count?: number;
};

export default async function ProducteursPage() {
  let producers: Producer[] = [];

  try {
    const res = await api.get("/producers");
    producers = res?.data ?? [];
  } catch (e) {
    console.error(e);
  }

  // Dégradé déterministe basé sur l'id
  const getGradient = (id: number) => {
    const hue = (id * 137) % 360;
    return `linear-gradient(135deg, hsl(${hue}, 70%, 85%), hsl(${(hue + 40) % 360}, 70%, 70%))`;
  };

  return (
    <PageContainer>
      <PageHeader 
        label="COMMUNAUTÉ" 
        title="Les producteurs" 
        subtitle="Découvre les beatmakers qui font vibrer la scène malgache."
      />

      {producers.length === 0 ? (
        <div className="bg-white border border-border rounded-3xl p-12 text-center">
          <div className="w-16 h-16 bg-accent-light text-accent rounded-full flex items-center justify-center mx-auto mb-4">
            <Mic2 className="w-8 h-8" />
          </div>
          <p className="text-content-secondary">Aucun producteur disponible pour le moment.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pb-16">
          {producers.map((producer) => (
            <Link
              key={producer.id}
              href={`/producteurs/${producer.id}`}
              className="group bg-white border border-border rounded-3xl p-6 hover:border-accent/30 hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col"
            >
              {/* Avatar */}
              <div className="relative mb-4">
                <div 
                  className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-bold text-white shadow-lg"
                  style={{ background: getGradient(producer.id) }}
                >
                  {producer.display_name.charAt(0).toUpperCase()}
                </div>
                {producer.verified && (
                  <div className="absolute bottom-0 right-0 w-6 h-6 bg-accent rounded-full flex items-center justify-center border-2 border-white">
                    <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}
              </div>

              {/* Infos */}
              <h2 className="text-lg font-bold text-content mb-1 group-hover:text-accent transition-colors">
                {producer.display_name}
              </h2>
              <p className="text-xs text-content-secondary mb-3">
                {producer.instrumentals_count ?? 0} instrumentale{(producer.instrumentals_count ?? 0) > 1 ? "s" : ""}
              </p>
              
              {producer.bio && (
                <p className="text-sm text-content-secondary line-clamp-2 mb-4 flex-1">
                  {producer.bio}
                </p>
              )}

              {/* Bouton */}
              <div className="flex items-center justify-between mt-auto pt-3 border-t border-border">
                <span className="text-xs font-semibold text-accent flex items-center gap-1 group-hover:gap-2 transition-all">
                  Voir le profil <ArrowRight className="w-3 h-3" />
                </span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </PageContainer>
  );
}