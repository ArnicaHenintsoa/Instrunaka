"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { api, auth } from "@/lib/api";
import Button from "@/components/ui/Button";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";

type Instrumental = {
  id: number;
  title: string;
  status: "pending" | "available" | "rejected";
  created_at: string;
  non_exclusive_price: number;
  exclusive_price: number;
  genre?: { label: string } | null;
  mood?: { label: string } | null;
  rhythm?: { label: string } | null;
};

export default function MesSoumissionsPage() {
  const router = useRouter();
  const [instrumentals, setInstrumentals] = useState<Instrumental[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/profil/mes-soumissions");
      return;
    }

    async function load() {
      try {
        const res = await api.get("/producer/instrumentals");
        setInstrumentals(res?.data ?? []);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    void load();
  }, [router]);

  if (loading) return <div className="container mx-auto px-4 py-16 text-center">Chargement...</div>;

  return (
    <div className="container mx-auto px-4 py-8 max-w-3xl">
      <div className="mb-6">
        <Link href="/profil" className="text-sm text-content-secondary hover:text-accent mb-4 inline-block">
          ← Retour au profil
        </Link>
        <h1 className="text-3xl font-bold mb-2">Mes soumissions</h1>
        <p className="text-content-secondary">Suivez l&apos;état de vos instrumentales proposées au catalogue.</p>
      </div>

      {instrumentals.length === 0 && (
        <Card padding="lg" className="text-center py-16">
          <span className="text-5xl block mb-4">📭</span>
          <p className="text-content-secondary mb-4">Vous n&apos;avez pas encore soumis d&apos;instrumentale.</p>
          <Link href="/profil/soumettre">
            <Button variant="primary">Soumettre ma première instrumentale</Button>
          </Link>
        </Card>
      )}

      <div className="space-y-4">
        {instrumentals.map((inst) => (
          <Card key={inst.id} padding="lg">
            <div className="flex items-start justify-between">
              <div>
                <h2 className="text-xl font-semibold">{inst.title}</h2>
                <p className="text-xs text-content-secondary mt-1">
                  Soumise le {new Date(inst.created_at).toLocaleDateString("fr-FR")}
                </p>
                <div className="flex gap-4 mt-3 text-sm">
                  <span className="text-content-secondary">Prix : {inst.non_exclusive_price} Ar / {inst.exclusive_price} Ar</span>
                  {inst.genre && <span className="text-content-secondary">Genre : {inst.genre.label}</span>}
                </div>
              </div>
              <Badge variant={
                inst.status === "available" ? "success" : 
                inst.status === "pending" ? "warning" : "danger"
              }>
                {inst.status === "available" ? "Publiée" : inst.status === "pending" ? "En attente" : "Refusée"}
              </Badge>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}