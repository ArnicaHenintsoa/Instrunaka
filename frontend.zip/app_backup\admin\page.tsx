"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { api, auth } from "@/lib/api";
import Card from "@/components/ui/Card";
import Badge from "@/components/ui/Badge";

type Stats = {
  users: { total: number; active: number; suspended: number; producers: number };
  instrumentals: { total: number; published: number; pending: number; unpublished: number };
  orders: { total: number; pending: number; validated: number; cancelled: number };
  revenue: { total: number };
  producer_requests: { pending: number };
  recent: {
    orders: { id: number; reference: string; amount: number; status: string; user?: { name: string }; instrumental?: { title: string } }[];
    instrumentals: { id: number; title: string; status: string; producer?: { user?: { name: string } } }[];
  };
};

export default function AdminDashboardPage() {
  const router = useRouter();
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!auth.isAuthenticated()) {
      router.push("/connexion?redirect=/admin");
      return;
    }

    async function load() {
      try {
        const res = await api.get("/admin/stats");
        setStats(res);
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }
    void load();
  }, [router]);

  if (loading) return <div className="container mx-auto px-4 py-16 text-center">Chargement...</div>;
  if (!stats) return null;

  const statCards = [
    { label: "Utilisateurs", value: stats.users.total, sub: `${stats.users.producers} producteurs`, color: "accent", href: "/admin/utilisateurs" },
    { label: "Catalogue", value: stats.instrumentals.total, sub: `${stats.instrumentals.published} publiées`, color: "success", href: "/admin/catalogue" },
    { label: "Commandes", value: stats.orders.total, sub: `${stats.orders.pending} en attente`, color: "warning", href: "/admin/commandes" },
    { label: "Revenus (Ar)", value: stats.revenue.total.toLocaleString("fr-FR"), sub: "Commandes validées", color: "accent" },
  ];

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Tableau de bord</h1>
        <p className="text-content-secondary">Vue d&apos;ensemble de la plateforme Aluna Instrumentales.</p>
      </div>

      {/* Cartes principales */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {statCards.map((card) => (
          <Link key={card.label} href={card.href ?? "#"}>
            <Card padding="lg" className="hover:shadow-lg transition-shadow cursor-pointer">
              <p className="text-sm text-content-secondary mb-2">{card.label}</p>
              <p className="text-3xl font-bold mb-1">{card.value}</p>
              <p className="text-xs text-content-secondary">{card.sub}</p>
            </Card>
          </Link>
        ))}
      </div>

      {/* Alertes */}
      {(stats.producer_requests.pending > 0 || stats.instrumentals.pending > 0) && (
        <Card padding="lg" className="mb-8 border-l-4 border-l-warning">
          <h3 className="font-semibold mb-3">⚠️ Actions en attente</h3>
          <div className="space-y-2 text-sm">
            {stats.producer_requests.pending > 0 && (
              <p>
                <Link href="/admin/demandes-producteur" className="text-accent hover:underline">
                  → {stats.producer_requests.pending} demande(s) producteur en attente
                </Link>
              </p>
            )}
            {stats.instrumentals.pending > 0 && (
              <p>
                <Link href="/admin/soumissions" className="text-accent hover:underline">
                  → {stats.instrumentals.pending} instrumentale(s) à valider
                </Link>
              </p>
            )}
            {stats.orders.pending > 0 && (
              <p>
                <Link href="/admin/commandes" className="text-accent hover:underline">
                  → {stats.orders.pending} commande(s) à vérifier
                </Link>
              </p>
            )}
          </div>
        </Card>
      )}

      {/* Activité récente */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card padding="lg">
          <h3 className="font-semibold mb-4">🛒 Dernières commandes</h3>
          {stats.recent.orders.length === 0 ? (
            <p className="text-sm text-content-secondary">Aucune commande récente.</p>
          ) : (
            <div className="space-y-3">
              {stats.recent.orders.map((order) => (
                <div key={order.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="text-sm font-medium">{order.instrumental?.title ?? "—"}</p>
                    <p className="text-xs text-content-secondary">par {order.user?.name ?? "—"}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{order.amount.toLocaleString("fr-FR")} Ar</p>
                    <Badge variant={order.status === "validated" ? "success" : order.status === "pending" ? "warning" : "danger"}>
                      {order.status}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card padding="lg">
          <h3 className="font-semibold mb-4">🎵 Dernières instrumentales</h3>
          {stats.recent.instrumentals.length === 0 ? (
            <p className="text-sm text-content-secondary">Aucune instrumentale récente.</p>
          ) : (
            <div className="space-y-3">
              {stats.recent.instrumentals.map((inst) => (
                <div key={inst.id} className="flex items-center justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="text-sm font-medium">{inst.title}</p>
                    <p className="text-xs text-content-secondary">par {inst.producer?.user?.name ?? "—"}</p>
                  </div>
                  <Badge variant={inst.status === "available" ? "success" : inst.status === "pending" ? "warning" : "danger"}>
                    {inst.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}