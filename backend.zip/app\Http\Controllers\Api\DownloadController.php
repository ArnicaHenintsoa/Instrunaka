<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\DownloadService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DownloadController extends Controller
{
    public function __construct(
        private readonly DownloadService $downloadService
    ) {}

    /**
     * Téléchargement sécurisé d'un fichier MP3 ou WAV.
     * §7 : accessible uniquement si la commande est validée.
     * §17 : traçabilité complète + fichier jamais exposé publiquement.
     */
    public function download(Request $request, int $orderId, string $fileType)
    {
        $order = Order::with('instrumental.files')->findOrFail($orderId);
        $user = $request->user();

        // Vérifie les droits et récupère le fichier
        $file = $this->downloadService->prepareDownload($user, $order, $fileType);

        // Enregistre le téléchargement (traçabilité §17)
        $this->downloadService->recordDownload(
            $user,
            $order,
            $file,
            $request->ip(),
            $request->userAgent()
        );

        // Si URL externe (démo), rediriger
        if ($this->downloadService->isExternal($file)) {
            return redirect($file->path);
        }

        // Sinon, servir depuis le storage privé
        $relativePath = $this->downloadService->resolvePath($file);

        /** @var \Illuminate\Filesystem\FilesystemAdapter $disk */
        $disk = Storage::disk('local');

        abort_unless($disk->exists($relativePath), 404, 'Fichier introuvable.');

        // Nom de téléchargement personnalisé
        $filename = sprintf(
            '%s.%s',
            str($order->instrumental->title)->slug(),
            $fileType
        );

        return $disk->download($relativePath, $filename, [
            'Content-Type' => $file->mime_type ?? 'audio/mpeg',
        ]);
    }
}