<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pack_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('pack_id')->constrained()->cascadeOnDelete();
            $table->foreignId('instrumental_id')->constrained()->cascadeOnDelete();
            $table->timestamps();

            $table->unique(['pack_id', 'instrumental_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pack_items');
    }
};