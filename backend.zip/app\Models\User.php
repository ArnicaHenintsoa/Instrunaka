<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role_id',
        'status',
        'is_producer',
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password'          => 'hashed',
            'is_producer'       => 'boolean',
        ];
    }

    // ------- Relations -------

    public function role(): BelongsTo
    {
        return $this->belongsTo(Role::class);
    }

    public function producer(): HasOne
    {
        return $this->hasOne(Producer::class);
    }

    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Instrumentales favorites de l'utilisateur.
     */
    public function favorites(): BelongsToMany
    {
        return $this->belongsToMany(Instrumental::class, 'favorites')
            ->withTimestamps();
    }

    /**
     * Avis publiés par l'utilisateur.
     */
    public function reviews(): HasMany
    {
        return $this->hasMany(Review::class);
    }

    /**
     * Producteurs suivis par l'utilisateur.
     */
    public function followedProducers(): BelongsToMany
    {
        return $this->belongsToMany(Producer::class, 'producer_follows')
            ->withTimestamps();
    }

    /**
     * Playlists de l'utilisateur.
     */
    public function playlists(): HasMany
    {
        return $this->hasMany(Playlist::class);
    }

    /**
     * Demandes pour devenir producteur.
     */
    public function producerRequests(): HasMany
    {
        return $this->hasMany(ProducerRequest::class);
    }

    /**
     * Dernière demande de producteur.
     */
    public function latestProducerRequest(): HasOne
    {
        return $this->hasOne(ProducerRequest::class)->latestOfMany();
    }

    /**
     * Sessions de connexion de l'utilisateur.
     */
    public function sessions(): HasMany
    {
        return $this->hasMany(UserSession::class);
    }

    /**
     * Historique des actions (audit logs).
     */
    public function auditLogs(): HasMany
    {
        return $this->hasMany(AuditLog::class);
    }

    // ------- Helpers -------

    public function isAdmin(): bool
    {
        return $this->role?->name === 'admin';
    }

    public function isProducer(): bool
    {
        return (bool) $this->is_producer;
    }

    /**
     * Utiliser notre notification personnalisée pour le reset de mot de passe.
     */
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new \App\Notifications\ResetPasswordNotification($token));
    }
}