<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Pack;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Config;

class PackController extends Controller
{
    public function index(): JsonResponse
    {
        if (!Config::get('platform.features.packs_enabled')) {
            return response()->json([
                'message' => 'Les packs ne sont pas encore disponibles.',
                'data'    => [],
            ]);
        }

        $packs = Pack::with('items.instrumental:id,title,cover_path')
            ->latest()
            ->get();

        return response()->json(['data' => $packs]);
    }

    public function show(int $id): JsonResponse
    {
        if (!Config::get('platform.features.packs_enabled')) {
            return response()->json([
                'message' => 'Les packs ne sont pas encore disponibles.',
            ], 404);
        }

        $pack = Pack::with('items.instrumental:id,title,cover_path')->findOrFail($id);

        return response()->json(['data' => $pack]);
    }
}