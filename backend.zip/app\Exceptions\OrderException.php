<?php

namespace App\Exceptions;

use RuntimeException;

/**
 * Exception dédiée aux règles métier des commandes.
 * Remplace l'usage générique de RuntimeException (SonarLint php:S112).
 */
class OrderException extends RuntimeException
{
}