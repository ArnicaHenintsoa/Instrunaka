<?php

namespace App\Console\Commands;

use App\Models\Order;
use Illuminate\Console\Command;

class ExpirePendingOrders extends Command
{
    protected $signature = 'aluna:expire-pending-orders';
    protected $description = 'Passe en "expired" les commandes pending de plus de 48h.';

    public function handle()
    {
        $count = Order::where('status', 'pending')
            ->where('created_at', '<', now()->subHours(48))
            ->update(['status' => 'expired']);

        $this->info("{$count} commande(s) expirée(s).");
    }
}