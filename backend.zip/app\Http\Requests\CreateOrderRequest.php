<?php

namespace App\Http\Requests;

use App\Services\OrderService;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class CreateOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true; // l'auth est gérée par le middleware
    }

    public function rules(): array
    {
        return [
            'instrumental_id' => ['required', 'integer', 'exists:instrumentals,id'],
            'type'            => [
                'required',
                'string',
                Rule::in([OrderService::TYPE_NON_EXCLUSIVE, OrderService::TYPE_EXCLUSIVE]),
            ],
        ];
    }

    public function messages(): array
    {
        return [
            'instrumental_id.required' => 'L\'instrumentale est obligatoire.',
            'instrumental_id.exists'   => 'Cette instrumentale n\'existe pas.',
            'type.required'            => 'Le type d\'achat est obligatoire.',
            'type.in'                  => 'Type d\'achat invalide.',
        ];
    }
}