<?php

namespace App\Services;

use App\Exceptions\OrderException;
use App\Exceptions\UnauthorizedOrderActionException;
use App\Models\Instrumental;
use App\Models\Order;
use App\Models\Payment;
use App\Models\PromoCode;
use App\Models\User;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderService
{
    public const TYPE_NON_EXCLUSIVE = 'non_exclusive';
    public const TYPE_EXCLUSIVE     = 'exclusive';

    public function createOrder(User $user, int $instrumentalId, string $type, ?string $promoCode = null): Order
    {
        if (! in_array($type, [self::TYPE_NON_EXCLUSIVE, self::TYPE_EXCLUSIVE], true)) {
            throw ValidationException::withMessages([
                'type' => ['Type d\'achat invalide.'],
            ]);
        }

        return DB::transaction(function () use ($user, $instrumentalId, $type, $promoCode) {
            $instrumental = Instrumental::where('id', $instrumentalId)
                ->lockForUpdate()
                ->firstOrFail();

            if (! $instrumental->isAvailable()) {
                throw ValidationException::withMessages([
                    'instrumental' => ['Cette instrumentale n\'est plus disponible.'],
                ]);
            }

            // Si une commande pending existe déjà pour ce triplet (user, inst, type), on la renvoie
            $existing = Order::where('user_id', $user->id)
                ->where('instrumental_id', $instrumental->id)
                ->where('type', $type)
                ->where('status', 'pending')
                ->first();

            if ($existing) {
                return $existing;
            }

            if ($type === self::TYPE_NON_EXCLUSIVE) {
                $alreadyPurchased = Order::where('user_id', $user->id)
                    ->where('instrumental_id', $instrumental->id)
                    ->where('status', 'validated')
                    ->where('type', self::TYPE_NON_EXCLUSIVE)
                    ->exists();

                if ($alreadyPurchased) {
                    throw ValidationException::withMessages([
                        'instrumental' => ['Vous avez déjà acheté cette instrumentale.'],
                    ]);
                }
            }

            $baseAmount = $type === self::TYPE_EXCLUSIVE
                ? Config::get('platform.prices.exclusive')
                : Config::get('platform.prices.non_exclusive');

            $discountAmount = 0;
            $promoCodeId = null;

            if ($promoCode) {
                $promo = PromoCode::where('code', strtoupper($promoCode))
                    ->lockForUpdate()
                    ->first();

                if (! $promo || ! $promo->isValid()) {
                    throw ValidationException::withMessages([
                        'promo_code' => ['Ce code promo est invalide ou expiré.'],
                    ]);
                }

                $discountAmount = (int) round(($baseAmount * $promo->discount_percent) / 100);
                $promoCodeId = $promo->id;
                $promo->increment('used_count');
            }

            $finalAmount = $baseAmount - $discountAmount;

            return Order::create([
                'reference'         => $this->generateReference(),
                'user_id'           => $user->id,
                'instrumental_id'   => $instrumental->id,
                'type'              => $type,
                'amount'            => $finalAmount,
                'original_amount'   => $baseAmount,
                'discount_amount'   => $discountAmount,
                'promo_code_id'     => $promoCodeId,
                'status'            => 'pending',
            ]);
        });
    }

    /**
     * Valide une commande (admin uniquement).
     * Ajoute le Payment + gère le remboursement des autres commandes pending.
     */
    public function validateOrder(
        Order $order,
        User $admin,
        string $senderReference,
        int $receivedAmount,
        ?string $note = null
    ): Order {
        if (! $admin->isAdmin()) {
            throw new UnauthorizedOrderActionException('Seul un administrateur peut valider une commande.');
        }

        return DB::transaction(function () use ($order, $admin, $senderReference, $receivedAmount, $note) {
            // 1. Verrouiller la commande et l'instrumentale
            $lockedOrder = Order::where('id', $order->id)->lockForUpdate()->firstOrFail();
            $instrumental = Instrumental::where('id', $lockedOrder->instrumental_id)
                ->lockForUpdate()
                ->firstOrFail();

            // 2. Re-vérifier le statut APRÈS verrouillage
            if ($lockedOrder->status !== 'pending') {
                throw new OrderException('Cette commande n\'est plus en attente.');
            }

            // 3. Vérifier que l'instrumentale est disponible (peu importe le type)
            if (! $instrumental->isAvailable()) {
                throw new OrderException('Cette instrumentale n\'est plus disponible.');
            }

            // 4. Vérifier le montant reçu
            if ($receivedAmount !== $lockedOrder->amount) {
                throw new OrderException(
                    "Le montant reçu ({$receivedAmount} Ar) ne correspond pas au montant attendu ({$lockedOrder->amount} Ar)."
                );
            }

            // 5. Si exclusif : passer les autres commandes pending de cette instrumentale à cancelled
            if ($lockedOrder->isExclusive()) {
                $instrumental->update(['status' => 'sold_exclusive']);

                Order::where('instrumental_id', $instrumental->id)
                    ->where('id', '!=', $lockedOrder->id)
                    ->where('status', 'pending')
                    ->update([
                        'status'          => 'cancelled',
                        'refund_required' => true,
                        'admin_note'      => 'Instrumentale vendue en exclusivité par un autre acheteur.',
                    ]);
            }

            // 6. Créer le Payment
            Payment::create([
                'order_id'         => $lockedOrder->id,
                'amount'           => $receivedAmount,
                'sender_reference' => $senderReference,
                'confirmed_by'     => $admin->id,
                'confirmed_at'     => now(),
            ]);

            // 7. Mettre à jour la commande
            $lockedOrder->update([
                'status'       => 'validated',
                'validated_by' => $admin->id,
                'validated_at' => now(),
                'admin_note'   => $note,
            ]);

            return $lockedOrder->fresh();
        });
    }

    public function rejectOrder(Order $order, User $admin, string $reason): Order
    {
        if (! $admin->isAdmin()) {
            throw new UnauthorizedOrderActionException('Seul un administrateur peut refuser une commande.');
        }

        if ($order->status !== 'pending') {
            throw new OrderException('Cette commande n\'est plus en attente.');
        }

        $order->update([
            'status'       => 'rejected',
            'validated_by' => $admin->id,
            'validated_at' => now(),
            'admin_note'   => $reason,
        ]);

        return $order->fresh();
    }

    public function cancelOrder(Order $order, User $user): Order
    {
        if ($order->user_id !== $user->id) {
            throw new UnauthorizedOrderActionException('Vous ne pouvez annuler que vos propres commandes.');
        }

        if ($order->status !== 'pending') {
            throw new OrderException('Seules les commandes en attente peuvent être annulées.');
        }

        $order->update(['status' => 'cancelled']);

        return $order->fresh();
    }

    private function generateReference(): string
    {
        do {
            $reference = sprintf(
                'ORD-%s-%s',
                now()->format('Ymd'),
                strtoupper(substr(bin2hex(random_bytes(4)), 0, 6))
            );
        } while (Order::where('reference', $reference)->exists());

        return $reference;
    }
}