<?php

namespace App\Exceptions;

use RuntimeException;

/**
 * Exception levée lorsqu'un utilisateur tente une action
 * non autorisée sur une commande (ex: non-admin qui valide).
 */
class UnauthorizedOrderActionException extends RuntimeException
{
}