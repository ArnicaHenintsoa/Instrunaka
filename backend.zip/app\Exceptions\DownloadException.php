<?php

namespace App\Exceptions;

use RuntimeException;

/**
 * Exception dédiée aux erreurs métier de téléchargement.
 */
class DownloadException extends RuntimeException
{
}